"""
Database service with async SQLAlchemy support.
"""

import json
from datetime import datetime, timedelta
from typing import Optional, List, Dict, Any
from contextlib import asynccontextmanager

from sqlalchemy.ext.asyncio import (
    create_async_engine,
    AsyncSession,
    async_sessionmaker
)
from sqlalchemy import select, update, delete, func, and_, or_
from sqlalchemy.dialects.sqlite import insert as sqlite_insert

from ..config.settings import get_settings
from ..models.database import (
    Base, Token, SecurityCheck, PriceSnapshot,
    Trade, Position, CreatorStats, BotState,
    TradeStatus, SecurityVerdict
)
from ..models.dto import TokenInfo, SecurityAnalysis, PositionInfo
from ..utils.logging import get_logger


logger = get_logger("database")


class DatabaseService:
    """Async database operations service."""
    
    def __init__(self):
        self.settings = get_settings()
        self.engine = create_async_engine(
            self.settings.database.url,
            echo=self.settings.database.echo,
            pool_pre_ping=True
        )
        self.async_session = async_sessionmaker(
            self.engine,
            class_=AsyncSession,
            expire_on_commit=False
        )
    
    async def init_db(self):
        """Initialize database schema."""
        async with self.engine.begin() as conn:
            await conn.run_sync(Base.metadata.create_all)
        logger.info("Database initialized")
    
    async def close(self):
        """Close database connections."""
        await self.engine.dispose()
        logger.info("Database connections closed")
    
    @asynccontextmanager
    async def session(self):
        """Get a database session context."""
        async with self.async_session() as session:
            try:
                yield session
                await session.commit()
            except Exception:
                await session.rollback()
                raise
    
    # ========================================================================
    # Token Operations
    # ========================================================================
    
    async def save_token(self, token_info: TokenInfo) -> Token:
        """Save or update a token."""
        async with self.session() as session:
            # Check if exists
            result = await session.execute(
                select(Token).where(Token.mint_address == token_info.mint_address)
            )
            existing = result.scalar_one_or_none()
            
            if existing:
                # Update existing
                existing.name = token_info.name
                existing.symbol = token_info.symbol
                existing.holder_count = token_info.holder_count
                existing.is_graduated = token_info.is_graduated
                if token_info.raydium_pool_address:
                    existing.raydium_pool_address = token_info.raydium_pool_address
                if token_info.migration_time:
                    existing.migration_time = token_info.migration_time
                if token_info.metadata:
                    existing.image_url = token_info.metadata.image_url
                    existing.description = token_info.metadata.description
                    existing.website = token_info.metadata.website
                    existing.twitter = token_info.metadata.twitter
                    existing.telegram = token_info.metadata.telegram
                token = existing
            else:
                # Create new
                token = Token(
                    mint_address=token_info.mint_address,
                    name=token_info.name,
                    symbol=token_info.symbol,
                    creator_address=token_info.creator_address,
                    bonding_curve_address=token_info.bonding_curve_address,
                    initial_liquidity_sol=token_info.liquidity_sol,
                    initial_market_cap_sol=token_info.market_cap_sol,
                    holder_count=token_info.holder_count,
                    is_graduated=token_info.is_graduated,
                    migration_time=token_info.migration_time,
                    raydium_pool_address=token_info.raydium_pool_address,
                )
                if token_info.metadata:
                    token.image_url = token_info.metadata.image_url
                    token.description = token_info.metadata.description
                    token.website = token_info.metadata.website
                    token.twitter = token_info.metadata.twitter
                    token.telegram = token_info.metadata.telegram
                
                session.add(token)
            
            await session.flush()
            logger.debug("Saved token", mint=token_info.mint_address, symbol=token_info.symbol)
            return token
    
    async def get_token(self, mint_address: str) -> Optional[Token]:
        """Get token by mint address."""
        async with self.session() as session:
            result = await session.execute(
                select(Token).where(Token.mint_address == mint_address)
            )
            return result.scalar_one_or_none()
    
    async def get_token_by_id(self, token_id: int) -> Optional[Token]:
        """Get token by ID."""
        async with self.session() as session:
            result = await session.execute(
                select(Token).where(Token.id == token_id)
            )
            return result.scalar_one_or_none()
    
    async def get_recent_tokens(
        self,
        limit: int = 50,
        since: Optional[datetime] = None
    ) -> List[Token]:
        """Get recently discovered tokens."""
        async with self.session() as session:
            query = select(Token).order_by(Token.discovered_at.desc()).limit(limit)
            if since:
                query = query.where(Token.discovered_at >= since)
            result = await session.execute(query)
            return list(result.scalars().all())
    
    async def blacklist_token(self, mint_address: str, reason: str):
        """Mark a token as blacklisted."""
        async with self.session() as session:
            await session.execute(
                update(Token)
                .where(Token.mint_address == mint_address)
                .values(is_blacklisted=True, blacklist_reason=reason)
            )
            logger.info("Token blacklisted", mint=mint_address, reason=reason)
    
    async def is_token_blacklisted(self, mint_address: str) -> bool:
        """Check if token is blacklisted."""
        async with self.session() as session:
            result = await session.execute(
                select(Token.is_blacklisted)
                .where(Token.mint_address == mint_address)
            )
            row = result.scalar_one_or_none()
            return row is True
    
    # ========================================================================
    # Security Check Operations
    # ========================================================================
    
    async def save_security_check(
        self,
        token_id: int,
        analysis: SecurityAnalysis
    ) -> SecurityCheck:
        """Save security analysis results."""
        async with self.session() as session:
            check = SecurityCheck(
                token_id=token_id,
                rugcheck_score=analysis.rugcheck.score if analysis.rugcheck else None,
                rugcheck_verdict=analysis.rugcheck.verdict.value if analysis.rugcheck else SecurityVerdict.UNKNOWN.value,
                rugcheck_risks=json.dumps(analysis.rugcheck.risks) if analysis.rugcheck else None,
                goplus_is_honeypot=analysis.goplus.is_honeypot if analysis.goplus else None,
                goplus_buy_tax=analysis.goplus.buy_tax if analysis.goplus else None,
                goplus_sell_tax=analysis.goplus.sell_tax if analysis.goplus else None,
                goplus_is_mintable=analysis.goplus.is_mintable if analysis.goplus else None,
                goplus_can_freeze=analysis.goplus.can_freeze if analysis.goplus else None,
                top_holder_percent=analysis.rugcheck.top_holder_percent if analysis.rugcheck else None,
                lp_locked=analysis.rugcheck.lp_locked if analysis.rugcheck else None,
                lp_burned=analysis.rugcheck.lp_burned if analysis.rugcheck else None,
                passed_checks=analysis.passed,
                failure_reasons=json.dumps(analysis.fail_reasons) if analysis.fail_reasons else None
            )
            session.add(check)
            await session.flush()
            logger.debug("Saved security check", token_id=token_id, passed=analysis.passed)
            return check
    
    async def get_latest_security_check(self, token_id: int) -> Optional[SecurityCheck]:
        """Get most recent security check for a token."""
        async with self.session() as session:
            result = await session.execute(
                select(SecurityCheck)
                .where(SecurityCheck.token_id == token_id)
                .order_by(SecurityCheck.checked_at.desc())
                .limit(1)
            )
            return result.scalar_one_or_none()
    
    # ========================================================================
    # Trade Operations
    # ========================================================================
    
    async def create_trade(
        self,
        token_id: int,
        direction: str,
        amount_sol: float,
        slippage_bps: int = 150,
        priority_fee: int = 0,
        is_paper: bool = True
    ) -> Trade:
        """Create a new trade record."""
        async with self.session() as session:
            trade = Trade(
                token_id=token_id,
                direction=direction,
                status=TradeStatus.PENDING.value,
                amount_sol=amount_sol,
                slippage_bps=slippage_bps,
                priority_fee_lamports=priority_fee,
                is_paper_trade=is_paper
            )
            session.add(trade)
            await session.flush()
            logger.info(
                "Trade created",
                trade_id=trade.id,
                direction=direction,
                amount=amount_sol
            )
            return trade
    
    async def update_trade_status(
        self,
        trade_id: int,
        status: TradeStatus,
        tx_signature: Optional[str] = None,
        executed_sol: Optional[float] = None,
        executed_tokens: Optional[float] = None,
        gas_fee: Optional[float] = None,
        error_message: Optional[str] = None
    ):
        """Update trade execution status."""
        async with self.session() as session:
            values = {"status": status.value}
            if tx_signature:
                values["tx_signature"] = tx_signature
            if executed_sol is not None:
                values["executed_amount_sol"] = executed_sol
            if executed_tokens is not None:
                values["executed_amount_tokens"] = executed_tokens
            if gas_fee is not None:
                values["gas_fee_sol"] = gas_fee
            if error_message:
                values["error_message"] = error_message
            if status in (TradeStatus.CONFIRMED, TradeStatus.FAILED):
                values["executed_at"] = datetime.utcnow()
            
            await session.execute(
                update(Trade)
                .where(Trade.id == trade_id)
                .values(**values)
            )
            logger.info("Trade updated", trade_id=trade_id, status=status.value)
    
    async def get_pending_trades(self) -> List[Trade]:
        """Get all pending trades."""
        async with self.session() as session:
            result = await session.execute(
                select(Trade).where(
                    Trade.status.in_([
                        TradeStatus.PENDING.value,
                        TradeStatus.SUBMITTED.value
                    ])
                )
            )
            return list(result.scalars().all())
    
    # ========================================================================
    # Position Operations
    # ========================================================================
    
    async def update_position(
        self,
        token_mint: str,
        amount_tokens: float,
        price: float,
        cost_sol: float,
        is_paper: bool = True
    ) -> Position:
        """Update or create a position."""
        async with self.session() as session:
            result = await session.execute(
                select(Position).where(Position.token_mint == token_mint)
            )
            position = result.scalar_one_or_none()
            
            if position:
                # Update existing position
                new_amount = position.amount_tokens + amount_tokens
                if new_amount <= 0:
                    # Position closed
                    position.amount_tokens = 0
                    position.closed_at = datetime.utcnow()
                else:
                    # Average in
                    total_cost = position.total_cost_sol + cost_sol
                    position.amount_tokens = new_amount
                    position.total_cost_sol = total_cost
                    position.average_entry_price = total_cost / new_amount
            else:
                # Create new position
                position = Position(
                    token_mint=token_mint,
                    amount_tokens=amount_tokens,
                    average_entry_price=price,
                    total_cost_sol=cost_sol,
                    is_paper_position=is_paper
                )
                session.add(position)
            
            await session.flush()
            return position
    
    async def get_position(self, token_mint: str) -> Optional[Position]:
        """Get position for a token."""
        async with self.session() as session:
            result = await session.execute(
                select(Position).where(
                    and_(
                        Position.token_mint == token_mint,
                        Position.amount_tokens > 0,
                        Position.closed_at.is_(None)
                    )
                )
            )
            return result.scalar_one_or_none()
    
    async def get_all_open_positions(self) -> List[Position]:
        """Get all open positions."""
        async with self.session() as session:
            result = await session.execute(
                select(Position).where(
                    and_(
                        Position.amount_tokens > 0,
                        Position.closed_at.is_(None)
                    )
                )
            )
            return list(result.scalars().all())
    
    # ========================================================================
    # Creator Stats Operations
    # ========================================================================
    
    async def update_creator_stats(
        self,
        creator_address: str,
        increment_tokens: bool = True,
        increment_rugs: bool = False,
        increment_migrations: bool = False
    ) -> CreatorStats:
        """Update creator statistics."""
        async with self.session() as session:
            result = await session.execute(
                select(CreatorStats)
                .where(CreatorStats.creator_address == creator_address)
            )
            stats = result.scalar_one_or_none()
            
            if stats:
                if increment_tokens:
                    stats.total_tokens_created += 1
                if increment_rugs:
                    stats.rugged_tokens += 1
                    # Decrease reputation for rugs
                    stats.reputation_score = max(0, stats.reputation_score - 20)
                if increment_migrations:
                    stats.successful_migrations += 1
                    # Increase reputation for successful migrations
                    stats.reputation_score = min(100, stats.reputation_score + 5)
            else:
                stats = CreatorStats(
                    creator_address=creator_address,
                    total_tokens_created=1 if increment_tokens else 0,
                    successful_migrations=1 if increment_migrations else 0,
                    rugged_tokens=1 if increment_rugs else 0
                )
                session.add(stats)
            
            await session.flush()
            return stats
    
    async def get_creator_stats(self, creator_address: str) -> Optional[CreatorStats]:
        """Get stats for a creator."""
        async with self.session() as session:
            result = await session.execute(
                select(CreatorStats)
                .where(CreatorStats.creator_address == creator_address)
            )
            return result.scalar_one_or_none()
    
    async def get_creator_token_count(self, creator_address: str) -> int:
        """Get number of tokens created by a creator."""
        async with self.session() as session:
            result = await session.execute(
                select(func.count(Token.id))
                .where(Token.creator_address == creator_address)
            )
            return result.scalar() or 0
    
    async def is_creator_blacklisted(self, creator_address: str) -> bool:
        """Check if creator is blacklisted."""
        async with self.session() as session:
            result = await session.execute(
                select(CreatorStats.is_blacklisted)
                .where(CreatorStats.creator_address == creator_address)
            )
            row = result.scalar_one_or_none()
            return row is True
    
    # ========================================================================
    # Price Snapshot Operations
    # ========================================================================
    
    async def save_price_snapshot(
        self,
        token_id: int,
        price_sol: float,
        price_usd: Optional[float] = None,
        market_cap: Optional[float] = None,
        liquidity: Optional[float] = None,
        volume_24h: Optional[float] = None,
        holders: Optional[int] = None
    ):
        """Save a price snapshot."""
        async with self.session() as session:
            snapshot = PriceSnapshot(
                token_id=token_id,
                price_sol=price_sol,
                price_usd=price_usd,
                market_cap_sol=market_cap,
                liquidity_sol=liquidity,
                volume_24h_sol=volume_24h,
                holder_count=holders
            )
            session.add(snapshot)
    
    # ========================================================================
    # Bot State Operations
    # ========================================================================
    
    async def set_state(self, key: str, value: Any):
        """Save bot state."""
        async with self.session() as session:
            json_value = json.dumps(value) if not isinstance(value, str) else value
            
            # SQLite upsert
            stmt = sqlite_insert(BotState).values(key=key, value=json_value)
            stmt = stmt.on_conflict_do_update(
                index_elements=[BotState.key],
                set_={"value": json_value, "updated_at": datetime.utcnow()}
            )
            await session.execute(stmt)
    
    async def get_state(self, key: str, default: Any = None) -> Any:
        """Get bot state."""
        async with self.session() as session:
            result = await session.execute(
                select(BotState.value).where(BotState.key == key)
            )
            row = result.scalar_one_or_none()
            if row is None:
                return default
            try:
                return json.loads(row)
            except json.JSONDecodeError:
                return row
