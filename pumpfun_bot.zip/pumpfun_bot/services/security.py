"""
Security analysis service for token safety checks.
Integrates with RugCheck, GoPlus, and custom heuristics.
"""

import asyncio
import json
from datetime import datetime
from typing import Optional, List, Dict, Any, Set

import aiohttp

from ..config.settings import get_settings
from ..models.dto import (
    TokenInfo, SecurityAnalysis, SecurityVerdict,
    RugCheckResult, GoPlusResult
)
from ..utils.helpers import RateLimiter, async_retry, AsyncCache
from ..utils.logging import get_logger


logger = get_logger("security")


class SecurityService:
    """
    Comprehensive security analysis for tokens.
    
    Performs:
    - RugCheck API validation
    - GoPlus security checks
    - Holder concentration analysis
    - Bundle detection
    - Creator reputation checks
    """
    
    def __init__(self, database_service=None):
        self.settings = get_settings()
        self.db = database_service
        
        # API clients
        self.rugcheck_url = self.settings.api.rugcheck_api_url.rstrip("/")
        self.goplus_url = self.settings.api.goplus_api_url.rstrip("/")
        
        # Rate limiters
        self.rugcheck_limiter = RateLimiter(rate=10, per=60)
        self.goplus_limiter = RateLimiter(rate=30, per=60)
        
        # Cache for API results
        self.cache = AsyncCache(maxsize=500, ttl=300)  # 5 minute cache
        
        # Session
        self._session: Optional[aiohttp.ClientSession] = None
        
        # Blacklists (loaded from config + remote)
        self._token_blacklist: Set[str] = set(self.settings.blacklist.token_addresses)
        self._creator_blacklist: Set[str] = set(self.settings.blacklist.creator_addresses)
    
    async def _get_session(self) -> aiohttp.ClientSession:
        """Get or create aiohttp session."""
        if self._session is None or self._session.closed:
            self._session = aiohttp.ClientSession(
                timeout=aiohttp.ClientTimeout(total=10)
            )
        return self._session
    
    async def close(self):
        """Close the session."""
        if self._session and not self._session.closed:
            await self._session.close()
    
    # ========================================================================
    # Main Analysis Entry Point
    # ========================================================================
    
    async def analyze_token(
        self,
        token: TokenInfo,
        check_creator: bool = True
    ) -> SecurityAnalysis:
        """
        Perform comprehensive security analysis on a token.
        """
        logger.info(
            "Analyzing token security",
            mint=token.mint_address,
            symbol=token.symbol
        )
        
        analysis = SecurityAnalysis(
            token_address=token.mint_address,
            analyzed_at=datetime.utcnow()
        )
        
        # Check blacklists first (fast fail)
        if await self._check_blacklists(token, analysis):
            return analysis
        
        # Run external checks concurrently
        rugcheck_task = self._get_rugcheck_analysis(token.mint_address)
        goplus_task = self._get_goplus_analysis(token.mint_address)
        
        # Creator check (if enabled and we have DB)
        creator_task = None
        if check_creator and self.db:
            creator_task = self._check_creator_reputation(token.creator_address)
        
        # Gather results
        results = await asyncio.gather(
            rugcheck_task,
            goplus_task,
            creator_task if creator_task else asyncio.sleep(0),
            return_exceptions=True
        )
        
        rugcheck_result = results[0] if not isinstance(results[0], Exception) else None
        goplus_result = results[1] if not isinstance(results[1], Exception) else None
        creator_issues = results[2] if creator_task and not isinstance(results[2], Exception) else []
        
        # Store results
        analysis.rugcheck = rugcheck_result
        analysis.goplus = goplus_result
        
        # Evaluate results
        self._evaluate_security(analysis, token, creator_issues)
        
        logger.info(
            "Security analysis complete",
            mint=token.mint_address,
            verdict=analysis.verdict.value,
            score=analysis.overall_score,
            passed=analysis.passed
        )
        
        return analysis
    
    # ========================================================================
    # Blacklist Checks
    # ========================================================================
    
    async def _check_blacklists(
        self,
        token: TokenInfo,
        analysis: SecurityAnalysis
    ) -> bool:
        """Check token and creator against blacklists."""
        if token.mint_address in self._token_blacklist:
            analysis.verdict = SecurityVerdict.DANGER
            analysis.overall_score = 0
            analysis.passed = False
            analysis.fail_reasons.append("Token is blacklisted")
            return True
        
        if token.creator_address in self._creator_blacklist:
            analysis.verdict = SecurityVerdict.DANGER
            analysis.overall_score = 0
            analysis.passed = False
            analysis.fail_reasons.append("Creator is blacklisted")
            return True
        
        return False
    
    async def refresh_blacklists(self):
        """Refresh blacklists from remote source."""
        if not self.settings.blacklist.remote_blacklist_url:
            return
        
        try:
            session = await self._get_session()
            async with session.get(self.settings.blacklist.remote_blacklist_url) as resp:
                if resp.status == 200:
                    data = await resp.json()
                    if "tokens" in data:
                        self._token_blacklist.update(data["tokens"])
                    if "creators" in data:
                        self._creator_blacklist.update(data["creators"])
                    logger.info(
                        "Blacklists refreshed",
                        tokens=len(self._token_blacklist),
                        creators=len(self._creator_blacklist)
                    )
        except Exception as e:
            logger.error("Failed to refresh blacklists", error=str(e))
    
    # ========================================================================
    # RugCheck Integration
    # ========================================================================
    
    @async_retry(max_attempts=2)
    async def _get_rugcheck_analysis(
        self,
        mint_address: str
    ) -> Optional[RugCheckResult]:
        """Get security analysis from RugCheck."""
        cache_key = f"rugcheck:{mint_address}"
        cached = await self.cache.get(cache_key)
        if cached:
            return RugCheckResult(**cached)
        
        await self.rugcheck_limiter.acquire()
        
        try:
            session = await self._get_session()
            url = f"{self.rugcheck_url}/tokens/{mint_address}/report"
            
            headers = {}
            if self.settings.api.rugcheck_api_key:
                headers["Authorization"] = f"Bearer {self.settings.api.rugcheck_api_key.get_secret_value()}"
            
            async with session.get(url, headers=headers) as resp:
                if resp.status == 404:
                    return None
                
                if resp.status != 200:
                    logger.warning("RugCheck API error", status=resp.status)
                    return None
                
                data = await resp.json()
                result = self._parse_rugcheck_response(data)
                await self.cache.set(cache_key, result.model_dump())
                return result
                
        except Exception as e:
            logger.error("RugCheck request failed", error=str(e))
            return None
    
    def _parse_rugcheck_response(self, data: Dict[str, Any]) -> RugCheckResult:
        """Parse RugCheck API response."""
        score = data.get("score", 50)
        
        verdict_map = {
            "Good": SecurityVerdict.SAFE,
            "Warning": SecurityVerdict.WARNING,
            "Danger": SecurityVerdict.DANGER,
        }
        verdict = verdict_map.get(data.get("verdict", "Unknown"), SecurityVerdict.UNKNOWN)
        
        risks = []
        for risk in data.get("risks", []):
            if isinstance(risk, dict):
                risks.append(f"{risk.get('name', 'Unknown')}: {risk.get('description', '')}")
            else:
                risks.append(str(risk))
        
        top_holder = None
        if "topHolders" in data and data["topHolders"]:
            top_holder = data["topHolders"][0].get("percentage", 0)
        
        return RugCheckResult(
            score=score,
            verdict=verdict,
            risks=risks,
            top_holder_percent=top_holder,
            is_mintable=data.get("mintable", False),
            has_freeze_authority=data.get("freezeAuthority") is not None,
            lp_locked=data.get("lpLocked", False),
            lp_burned=data.get("lpBurned", False)
        )
    
    # ========================================================================
    # GoPlus Integration
    # ========================================================================
    
    @async_retry(max_attempts=2)
    async def _get_goplus_analysis(
        self,
        mint_address: str
    ) -> Optional[GoPlusResult]:
        """Get security analysis from GoPlus Security API."""
        cache_key = f"goplus:{mint_address}"
        cached = await self.cache.get(cache_key)
        if cached:
            return GoPlusResult(**cached)
        
        await self.goplus_limiter.acquire()
        
        try:
            session = await self._get_session()
            url = f"{self.goplus_url}/solana/token_security"
            params = {"contract_addresses": mint_address}
            
            async with session.get(url, params=params) as resp:
                if resp.status != 200:
                    return None
                
                data = await resp.json()
                
                if data.get("code") != 1:
                    return None
                
                result_data = data.get("result", {}).get(mint_address.lower(), {})
                if not result_data:
                    return None
                
                result = self._parse_goplus_response(result_data)
                await self.cache.set(cache_key, result.model_dump())
                return result
                
        except Exception as e:
            logger.error("GoPlus request failed", error=str(e))
            return None
    
    def _parse_goplus_response(self, data: Dict[str, Any]) -> GoPlusResult:
        """Parse GoPlus API response."""
        def to_bool(val) -> bool:
            if val is None:
                return False
            if isinstance(val, bool):
                return val
            return str(val) == "1"
        
        def to_float(val) -> float:
            try:
                return float(val) if val else 0.0
            except (ValueError, TypeError):
                return 0.0
        
        return GoPlusResult(
            is_honeypot=to_bool(data.get("is_honeypot")),
            buy_tax=to_float(data.get("buy_tax")) * 100,
            sell_tax=to_float(data.get("sell_tax")) * 100,
            is_mintable=to_bool(data.get("is_mintable")),
            can_freeze=to_bool(data.get("can_freeze")),
            is_proxy=to_bool(data.get("is_proxy")),
            has_blacklist=to_bool(data.get("is_blacklisted")),
            is_open_source=to_bool(data.get("is_open_source")),
            is_in_dex=to_bool(data.get("is_in_dex")),
            holder_count=int(data.get("holder_count", 0)) if data.get("holder_count") else None
        )
    
    # ========================================================================
    # Creator Analysis
    # ========================================================================
    
    async def _check_creator_reputation(
        self,
        creator_address: str
    ) -> List[str]:
        """Check creator's history and reputation."""
        warnings = []
        
        if not self.db:
            return warnings
        
        stats = await self.db.get_creator_stats(creator_address)
        
        if stats:
            max_tokens = self.settings.filters.max_creator_tokens
            if stats.total_tokens_created >= max_tokens:
                warnings.append(
                    f"Creator has launched {stats.total_tokens_created} tokens (limit: {max_tokens})"
                )
            
            if stats.rugged_tokens > 0:
                warnings.append(f"Creator has {stats.rugged_tokens} rugged token(s)")
            
            if stats.reputation_score < 30:
                warnings.append(f"Creator has low reputation: {stats.reputation_score:.0f}/100")
        else:
            token_count = await self.db.get_creator_token_count(creator_address)
            max_tokens = self.settings.filters.max_creator_tokens
            
            if token_count >= max_tokens:
                warnings.append(f"Creator has launched {token_count} tokens (limit: {max_tokens})")
        
        return warnings
    
    # ========================================================================
    # Evaluation Logic
    # ========================================================================
    
    def _evaluate_security(
        self,
        analysis: SecurityAnalysis,
        token: TokenInfo,
        creator_issues: List[str]
    ):
        """Evaluate all security findings and produce final verdict."""
        score = 100.0
        filters = self.settings.filters
        
        # RugCheck evaluation (40% weight)
        if analysis.rugcheck:
            rc = analysis.rugcheck
            score -= (100 - rc.score) * 0.4
            
            if rc.verdict == SecurityVerdict.DANGER:
                analysis.fail_reasons.append("RugCheck verdict: DANGER")
                score -= 30
            elif rc.verdict == SecurityVerdict.WARNING:
                analysis.warnings.append("RugCheck verdict: WARNING")
                score -= 10
            
            if rc.is_mintable:
                analysis.warnings.append("Token is mintable")
                score -= 15
            
            if rc.has_freeze_authority:
                analysis.warnings.append("Token has freeze authority")
                score -= 15
            
            if rc.top_holder_percent and rc.top_holder_percent > filters.max_top_holder_percent:
                analysis.fail_reasons.append(
                    f"Top holder owns {rc.top_holder_percent:.1f}% (max: {filters.max_top_holder_percent}%)"
                )
                score -= 20
            
            if not rc.lp_burned and not rc.lp_locked:
                analysis.warnings.append("LP is not locked or burned")
                score -= 10
            elif rc.lp_burned:
                analysis.pass_reasons.append("LP is burned")
            elif rc.lp_locked:
                analysis.pass_reasons.append("LP is locked")
        
        # GoPlus evaluation
        if analysis.goplus:
            gp = analysis.goplus
            
            if gp.is_honeypot:
                analysis.fail_reasons.append("Honeypot detected")
                score = 0
            
            if gp.buy_tax > filters.max_buy_tax_percent:
                analysis.fail_reasons.append(
                    f"High buy tax: {gp.buy_tax:.1f}% (max: {filters.max_buy_tax_percent}%)"
                )
                score -= 25
            
            if gp.sell_tax > filters.max_sell_tax_percent:
                analysis.fail_reasons.append(
                    f"High sell tax: {gp.sell_tax:.1f}% (max: {filters.max_sell_tax_percent}%)"
                )
                score -= 25
            
            if gp.can_freeze:
                analysis.warnings.append("Contract can freeze transfers")
                score -= 10
            
            if gp.has_blacklist:
                analysis.warnings.append("Contract has blacklist functionality")
                score -= 10
        
        # Creator issues
        for issue in creator_issues:
            analysis.warnings.append(f"Creator: {issue}")
            score -= 15
        
        # Token metrics
        if token.liquidity_sol < filters.min_liquidity_sol:
            analysis.fail_reasons.append(
                f"Low liquidity: {token.liquidity_sol:.2f} SOL (min: {filters.min_liquidity_sol} SOL)"
            )
            score -= 20
        
        if token.holder_count < filters.min_holders:
            analysis.warnings.append(
                f"Low holder count: {token.holder_count} (min: {filters.min_holders})"
            )
            score -= 10
        
        # Finalize
        analysis.overall_score = max(0, min(100, score))
        
        if analysis.fail_reasons:
            analysis.verdict = SecurityVerdict.DANGER
            analysis.passed = False
        elif analysis.overall_score >= 70:
            analysis.verdict = SecurityVerdict.SAFE
            analysis.passed = True
        elif analysis.overall_score >= 50:
            analysis.verdict = SecurityVerdict.WARNING
            analysis.passed = len(analysis.warnings) < 3
        else:
            analysis.verdict = SecurityVerdict.DANGER
            analysis.passed = False
        
        if analysis.overall_score < filters.min_rugcheck_score:
            analysis.passed = False
    
    # ========================================================================
    # Utility Methods
    # ========================================================================
    
    def is_token_blacklisted(self, mint_address: str) -> bool:
        """Quick synchronous blacklist check."""
        return mint_address in self._token_blacklist
    
    def is_creator_blacklisted(self, creator_address: str) -> bool:
        """Quick synchronous creator blacklist check."""
        return creator_address in self._creator_blacklist
    
    def add_to_blacklist(self, address: str, is_creator: bool = False):
        """Add an address to the blacklist."""
        if is_creator:
            self._creator_blacklist.add(address)
        else:
            self._token_blacklist.add(address)
