"""
Trading service for executing buys/sells on Solana.
Supports both paper trading and live trading.
"""

import asyncio
import base64
import json
from datetime import datetime
from decimal import Decimal
from typing import Optional, Dict, Any, Tuple

from solana.rpc.async_api import AsyncClient
from solana.rpc.commitment import Confirmed
from solana.transaction import Transaction
from solders.keypair import Keypair
from solders.pubkey import Pubkey
from solders.signature import Signature
from solders.system_program import transfer, TransferParams

from ..config.settings import get_settings
from ..models.database import TradeStatus
from ..models.dto import (
    TradeRequest, TradeResult, TradeDirection,
    PositionInfo, PortfolioSummary
)
from ..utils.helpers import (
    lamports_to_sol, sol_to_lamports,
    calculate_price_impact, format_sol
)
from ..utils.logging import get_logger


logger = get_logger("trading")


class TradingError(Exception):
    """Custom exception for trading errors."""
    def __init__(self, message: str, code: str = "UNKNOWN"):
        super().__init__(message)
        self.code = code


class TradingService:
    """
    Trading service for executing swaps on Solana.
    
    Features:
    - Paper trading mode for testing
    - Live trading with Raydium/Jupiter
    - Position management
    - Stop-loss and take-profit orders
    - Transaction confirmation handling
    """
    
    # Jupiter API for swaps
    JUPITER_API = "https://quote-api.jup.ag/v6"
    
    # Native SOL mint
    SOL_MINT = "So11111111111111111111111111111111111111112"
    
    def __init__(self, database_service=None, pumpfun_api=None):
        self.settings = get_settings()
        self.db = database_service
        self.pumpfun = pumpfun_api
        
        # Solana RPC client
        self.rpc = AsyncClient(
            self.settings.api.solana_rpc_url,
            commitment=Confirmed
        )
        
        # Wallet (loaded from environment or secure storage)
        self._keypair: Optional[Keypair] = None
        
        # Paper trading state
        self._paper_balance_sol = 10.0  # Starting paper balance
        self._paper_positions: Dict[str, Dict] = {}  # mint -> position
        
        # Active orders for stop-loss/take-profit
        self._active_orders: Dict[str, Dict] = {}
    
    async def close(self):
        """Close RPC connection."""
        await self.rpc.close()
    
    # ========================================================================
    # Wallet Management
    # ========================================================================
    
    def load_wallet(self, private_key: str):
        """
        Load wallet from private key.
        
        Args:
            private_key: Base58 encoded private key
        
        WARNING: Never hardcode private keys. Use secure storage.
        """
        try:
            key_bytes = base64.b58decode(private_key)
            self._keypair = Keypair.from_bytes(key_bytes)
            logger.info(
                "Wallet loaded",
                pubkey=str(self._keypair.pubkey())[:8] + "..."
            )
        except Exception as e:
            logger.error("Failed to load wallet", error=str(e))
            raise TradingError("Invalid private key", code="INVALID_KEY")
    
    @property
    def wallet_address(self) -> Optional[str]:
        """Get wallet public key."""
        if self._keypair:
            return str(self._keypair.pubkey())
        return None
    
    async def get_balance(self) -> float:
        """Get SOL balance of wallet."""
        if self.settings.trading.paper_trading:
            return self._paper_balance_sol
        
        if not self._keypair:
            raise TradingError("Wallet not loaded", code="NO_WALLET")
        
        try:
            result = await self.rpc.get_balance(self._keypair.pubkey())
            return lamports_to_sol(result.value)
        except Exception as e:
            logger.error("Failed to get balance", error=str(e))
            raise TradingError(f"Failed to get balance: {e}", code="RPC_ERROR")
    
    # ========================================================================
    # Trading Execution
    # ========================================================================
    
    async def execute_trade(self, request: TradeRequest) -> TradeResult:
        """
        Execute a trade (buy or sell).
        
        Args:
            request: TradeRequest with details
        
        Returns:
            TradeResult with execution details
        """
        logger.info(
            "Executing trade",
            direction=request.direction.value,
            token=request.token_mint,
            amount=request.amount_sol
        )
        
        # Validate request
        await self._validate_trade(request)
        
        # Route to paper or live trading
        if self.settings.trading.paper_trading:
            return await self._execute_paper_trade(request)
        else:
            return await self._execute_live_trade(request)
    
    async def _validate_trade(self, request: TradeRequest):
        """Validate trade request."""
        balance = await self.get_balance()
        
        if request.direction == TradeDirection.BUY:
            if request.amount_sol > balance:
                raise TradingError(
                    f"Insufficient balance: {balance:.4f} SOL",
                    code="INSUFFICIENT_BALANCE"
                )
            
            if request.amount_sol > self.settings.trading.max_position_sol:
                raise TradingError(
                    f"Exceeds max position: {self.settings.trading.max_position_sol} SOL",
                    code="MAX_POSITION_EXCEEDED"
                )
    
    # ========================================================================
    # Paper Trading
    # ========================================================================
    
    async def _execute_paper_trade(self, request: TradeRequest) -> TradeResult:
        """Execute a paper (simulated) trade."""
        try:
            # Get current price
            price = await self._get_token_price(request.token_mint)
            if price <= 0:
                return TradeResult(
                    success=False,
                    direction=request.direction,
                    requested_amount_sol=request.amount_sol,
                    error_code="PRICE_UNAVAILABLE",
                    error_message="Could not fetch token price"
                )
            
            # Calculate amounts
            if request.direction == TradeDirection.BUY:
                # Simulate slippage
                effective_price = price * (1 + request.slippage_bps / 10000)
                tokens_received = request.amount_sol / effective_price
                gas_fee = 0.000005  # Simulated gas
                
                # Update paper balance
                self._paper_balance_sol -= (request.amount_sol + gas_fee)
                
                # Update paper position
                if request.token_mint in self._paper_positions:
                    pos = self._paper_positions[request.token_mint]
                    total_cost = pos["cost"] + request.amount_sol
                    total_tokens = pos["tokens"] + tokens_received
                    pos["tokens"] = total_tokens
                    pos["cost"] = total_cost
                    pos["avg_price"] = total_cost / total_tokens
                else:
                    self._paper_positions[request.token_mint] = {
                        "tokens": tokens_received,
                        "cost": request.amount_sol,
                        "avg_price": effective_price,
                        "opened_at": datetime.utcnow()
                    }
                
                executed_sol = request.amount_sol
                executed_tokens = tokens_received
                
            else:  # SELL
                if request.token_mint not in self._paper_positions:
                    return TradeResult(
                        success=False,
                        direction=request.direction,
                        requested_amount_sol=request.amount_sol,
                        error_code="NO_POSITION",
                        error_message="No position to sell"
                    )
                
                pos = self._paper_positions[request.token_mint]
                tokens_to_sell = request.amount_sol / price
                
                if tokens_to_sell > pos["tokens"]:
                    tokens_to_sell = pos["tokens"]
                
                # Simulate slippage
                effective_price = price * (1 - request.slippage_bps / 10000)
                sol_received = tokens_to_sell * effective_price
                gas_fee = 0.000005
                
                # Update paper balance
                self._paper_balance_sol += (sol_received - gas_fee)
                
                # Update position
                pos["tokens"] -= tokens_to_sell
                if pos["tokens"] <= 0:
                    del self._paper_positions[request.token_mint]
                
                executed_sol = sol_received
                executed_tokens = tokens_to_sell
            
            # Save to database
            trade_id = None
            if self.db:
                token = await self.db.get_token(request.token_mint)
                if token:
                    trade = await self.db.create_trade(
                        token_id=token.id,
                        direction=request.direction.value,
                        amount_sol=request.amount_sol,
                        is_paper=True
                    )
                    await self.db.update_trade_status(
                        trade_id=trade.id,
                        status=TradeStatus.CONFIRMED,
                        executed_sol=executed_sol,
                        executed_tokens=executed_tokens,
                        gas_fee=gas_fee
                    )
                    trade_id = trade.id
            
            logger.info(
                "Paper trade executed",
                direction=request.direction.value,
                tokens=executed_tokens,
                price=price,
                balance=self._paper_balance_sol
            )
            
            return TradeResult(
                success=True,
                trade_id=trade_id,
                tx_signature=f"PAPER_{datetime.utcnow().timestamp()}",
                direction=request.direction,
                requested_amount_sol=request.amount_sol,
                executed_amount_sol=executed_sol,
                executed_amount_tokens=executed_tokens,
                price_per_token=price,
                gas_fee_sol=gas_fee,
                executed_at=datetime.utcnow()
            )
            
        except Exception as e:
            logger.error("Paper trade failed", error=str(e))
            return TradeResult(
                success=False,
                direction=request.direction,
                requested_amount_sol=request.amount_sol,
                error_code="EXECUTION_ERROR",
                error_message=str(e)
            )
    
    # ========================================================================
    # Live Trading
    # ========================================================================
    
    async def _execute_live_trade(self, request: TradeRequest) -> TradeResult:
        """Execute a live trade using Jupiter aggregator."""
        if not self._keypair:
            return TradeResult(
                success=False,
                direction=request.direction,
                requested_amount_sol=request.amount_sol,
                error_code="NO_WALLET",
                error_message="Wallet not loaded"
            )
        
        try:
            # Get quote from Jupiter
            quote = await self._get_jupiter_quote(request)
            if not quote:
                return TradeResult(
                    success=False,
                    direction=request.direction,
                    requested_amount_sol=request.amount_sol,
                    error_code="QUOTE_FAILED",
                    error_message="Could not get swap quote"
                )
            
            # Get swap transaction
            swap_tx = await self._get_jupiter_swap_tx(quote)
            if not swap_tx:
                return TradeResult(
                    success=False,
                    direction=request.direction,
                    requested_amount_sol=request.amount_sol,
                    error_code="SWAP_TX_FAILED",
                    error_message="Could not create swap transaction"
                )
            
            # Sign and send transaction
            signature = await self._send_transaction(swap_tx)
            
            # Wait for confirmation
            confirmed = await self._confirm_transaction(signature)
            
            if confirmed:
                # Parse results from transaction
                executed_sol = float(quote.get("outAmount", 0)) / 1e9
                executed_tokens = float(quote.get("inAmount", 0)) / 1e6
                
                # Save to database
                trade_id = None
                if self.db:
                    token = await self.db.get_token(request.token_mint)
                    if token:
                        trade = await self.db.create_trade(
                            token_id=token.id,
                            direction=request.direction.value,
                            amount_sol=request.amount_sol,
                            is_paper=False
                        )
                        await self.db.update_trade_status(
                            trade_id=trade.id,
                            status=TradeStatus.CONFIRMED,
                            tx_signature=str(signature),
                            executed_sol=executed_sol,
                            executed_tokens=executed_tokens
                        )
                        trade_id = trade.id
                
                return TradeResult(
                    success=True,
                    trade_id=trade_id,
                    tx_signature=str(signature),
                    direction=request.direction,
                    requested_amount_sol=request.amount_sol,
                    executed_amount_sol=executed_sol,
                    executed_amount_tokens=executed_tokens,
                    executed_at=datetime.utcnow()
                )
            else:
                return TradeResult(
                    success=False,
                    direction=request.direction,
                    requested_amount_sol=request.amount_sol,
                    tx_signature=str(signature),
                    error_code="CONFIRMATION_FAILED",
                    error_message="Transaction not confirmed"
                )
                
        except Exception as e:
            logger.error("Live trade failed", error=str(e))
            return TradeResult(
                success=False,
                direction=request.direction,
                requested_amount_sol=request.amount_sol,
                error_code="EXECUTION_ERROR",
                error_message=str(e)
            )
    
    async def _get_jupiter_quote(self, request: TradeRequest) -> Optional[Dict]:
        """Get swap quote from Jupiter."""
        import aiohttp
        
        if request.direction == TradeDirection.BUY:
            input_mint = self.SOL_MINT
            output_mint = request.token_mint
            amount = sol_to_lamports(request.amount_sol)
        else:
            input_mint = request.token_mint
            output_mint = self.SOL_MINT
            amount = int(request.amount_sol * 1e6)  # Assuming 6 decimals
        
        params = {
            "inputMint": input_mint,
            "outputMint": output_mint,
            "amount": amount,
            "slippageBps": request.slippage_bps
        }
        
        async with aiohttp.ClientSession() as session:
            async with session.get(
                f"{self.JUPITER_API}/quote",
                params=params
            ) as resp:
                if resp.status == 200:
                    return await resp.json()
        return None
    
    async def _get_jupiter_swap_tx(self, quote: Dict) -> Optional[bytes]:
        """Get swap transaction from Jupiter."""
        import aiohttp
        
        payload = {
            "quoteResponse": quote,
            "userPublicKey": str(self._keypair.pubkey()),
            "prioritizationFeeLamports": self.settings.trading.priority_fee_lamports
        }
        
        async with aiohttp.ClientSession() as session:
            async with session.post(
                f"{self.JUPITER_API}/swap",
                json=payload
            ) as resp:
                if resp.status == 200:
                    data = await resp.json()
                    return base64.b64decode(data.get("swapTransaction", ""))
        return None
    
    async def _send_transaction(self, tx_bytes: bytes) -> Signature:
        """Sign and send transaction."""
        # Deserialize and sign
        tx = Transaction.deserialize(tx_bytes)
        tx.sign(self._keypair)
        
        # Send
        result = await self.rpc.send_transaction(tx)
        return Signature.from_string(result.value)
    
    async def _confirm_transaction(
        self,
        signature: Signature,
        timeout: float = 30.0
    ) -> bool:
        """Wait for transaction confirmation."""
        start = asyncio.get_event_loop().time()
        
        while asyncio.get_event_loop().time() - start < timeout:
            try:
                result = await self.rpc.get_signature_statuses([signature])
                status = result.value[0]
                
                if status and status.confirmation_status:
                    if status.err:
                        logger.error("Transaction failed", error=status.err)
                        return False
                    return True
                
            except Exception as e:
                logger.warning("Confirmation check failed", error=str(e))
            
            await asyncio.sleep(0.5)
        
        return False
    
    # ========================================================================
    # Price and Position Management
    # ========================================================================
    
    async def _get_token_price(self, mint_address: str) -> float:
        """Get current token price in SOL."""
        # Try PumpFun API first
        if self.pumpfun:
            token = await self.pumpfun.get_token_details(mint_address)
            if token and token.price_sol > 0:
                return token.price_sol
        
        # Fallback to Jupiter quote
        try:
            import aiohttp
            
            params = {
                "inputMint": self.SOL_MINT,
                "outputMint": mint_address,
                "amount": sol_to_lamports(1.0),  # 1 SOL worth
            }
            
            async with aiohttp.ClientSession() as session:
                async with session.get(
                    f"{self.JUPITER_API}/quote",
                    params=params
                ) as resp:
                    if resp.status == 200:
                        data = await resp.json()
                        out_amount = float(data.get("outAmount", 0))
                        if out_amount > 0:
                            # Price = 1 SOL / tokens received
                            return 1.0 / (out_amount / 1e6)
        except Exception:
            pass
        
        return 0.0
    
    async def get_position(self, mint_address: str) -> Optional[PositionInfo]:
        """Get current position for a token."""
        if self.settings.trading.paper_trading:
            if mint_address not in self._paper_positions:
                return None
            
            pos = self._paper_positions[mint_address]
            current_price = await self._get_token_price(mint_address)
            current_value = pos["tokens"] * current_price
            unrealized_pnl = current_value - pos["cost"]
            pnl_percent = (unrealized_pnl / pos["cost"]) * 100 if pos["cost"] > 0 else 0
            
            return PositionInfo(
                token_mint=mint_address,
                token_symbol="???",
                amount_tokens=pos["tokens"],
                average_entry_price=pos["avg_price"],
                current_price=current_price,
                total_cost_sol=pos["cost"],
                current_value_sol=current_value,
                unrealized_pnl_sol=unrealized_pnl,
                unrealized_pnl_percent=pnl_percent,
                is_paper=True,
                opened_at=pos["opened_at"]
            )
        
        # Live positions from DB
        if self.db:
            db_pos = await self.db.get_position(mint_address)
            if db_pos:
                current_price = await self._get_token_price(mint_address)
                current_value = db_pos.amount_tokens * current_price
                unrealized_pnl = current_value - db_pos.total_cost_sol
                pnl_percent = (unrealized_pnl / db_pos.total_cost_sol) * 100 if db_pos.total_cost_sol > 0 else 0
                
                return PositionInfo(
                    token_mint=mint_address,
                    token_symbol="???",
                    amount_tokens=db_pos.amount_tokens,
                    average_entry_price=db_pos.average_entry_price,
                    current_price=current_price,
                    total_cost_sol=db_pos.total_cost_sol,
                    current_value_sol=current_value,
                    unrealized_pnl_sol=unrealized_pnl,
                    unrealized_pnl_percent=pnl_percent,
                    stop_loss_price=db_pos.stop_loss_price,
                    take_profit_price=db_pos.take_profit_price,
                    is_paper=db_pos.is_paper_position,
                    opened_at=db_pos.opened_at
                )
        
        return None
    
    async def get_portfolio(self) -> PortfolioSummary:
        """Get portfolio summary."""
        positions = []
        total_value = await self.get_balance()
        total_cost = 0.0
        
        if self.settings.trading.paper_trading:
            for mint, pos in self._paper_positions.items():
                position_info = await self.get_position(mint)
                if position_info:
                    positions.append(position_info)
                    total_value += position_info.current_value_sol
                    total_cost += position_info.total_cost_sol
        else:
            # Get from database
            if self.db:
                db_positions = await self.db.get_all_open_positions()
                for db_pos in db_positions:
                    position_info = await self.get_position(db_pos.token_mint)
                    if position_info:
                        positions.append(position_info)
                        total_value += position_info.current_value_sol
                        total_cost += position_info.total_cost_sol
        
        unrealized_pnl = sum(p.unrealized_pnl_sol for p in positions)
        realized_pnl = sum(p.realized_pnl_sol for p in positions)
        
        return PortfolioSummary(
            total_value_sol=total_value,
            total_cost_sol=total_cost,
            total_unrealized_pnl_sol=unrealized_pnl,
            total_realized_pnl_sol=realized_pnl,
            position_count=len(positions),
            positions=positions,
            is_paper=self.settings.trading.paper_trading
        )
