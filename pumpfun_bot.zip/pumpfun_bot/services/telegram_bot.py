"""
Telegram bot for alerts and trading commands.
"""

import asyncio
from datetime import datetime
from typing import Optional, Dict, Any, Callable

from telegram import Update, Bot, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import (
    Application,
    ApplicationBuilder,
    CommandHandler,
    CallbackQueryHandler,
    MessageHandler,
    ContextTypes,
    filters
)

from ..config.settings import get_settings
from ..models.dto import (
    Alert, AlertType, TokenInfo, SecurityAnalysis,
    TradeDirection, PositionInfo, PortfolioSummary
)
from ..utils.helpers import format_sol, format_percent, truncate_address
from ..utils.logging import get_logger


logger = get_logger("telegram")


class TelegramService:
    """
    Telegram bot for:
    - Sending alerts about new tokens
    - Trading commands
    - Portfolio management
    - Configuration
    """
    
    def __init__(
        self,
        trading_service=None,
        pumpfun_api=None,
        security_service=None,
        database_service=None
    ):
        self.settings = get_settings()
        self.trading = trading_service
        self.pumpfun = pumpfun_api
        self.security = security_service
        self.db = database_service
        
        self._app: Optional[Application] = None
        self._bot: Optional[Bot] = None
        
        # Track current analysis per user
        self._user_context: Dict[int, Dict[str, Any]] = {}
    
    async def start(self):
        """Initialize and start the Telegram bot."""
        if not self.settings.telegram.bot_token:
            logger.warning("Telegram bot token not configured")
            return
        
        token = self.settings.telegram.bot_token.get_secret_value()
        
        self._app = (
            ApplicationBuilder()
            .token(token)
            .build()
        )
        
        # Register handlers
        self._register_handlers()
        
        # Initialize
        await self._app.initialize()
        await self._app.start()
        
        # Start polling
        await self._app.updater.start_polling(
            allowed_updates=Update.ALL_TYPES,
            drop_pending_updates=True
        )
        
        self._bot = self._app.bot
        logger.info("Telegram bot started")
    
    async def stop(self):
        """Stop the Telegram bot."""
        if self._app:
            await self._app.updater.stop()
            await self._app.stop()
            await self._app.shutdown()
            logger.info("Telegram bot stopped")
    
    def _register_handlers(self):
        """Register command and callback handlers."""
        app = self._app
        
        # Command handlers
        app.add_handler(CommandHandler("start", self._cmd_start))
        app.add_handler(CommandHandler("help", self._cmd_help))
        app.add_handler(CommandHandler("status", self._cmd_status))
        app.add_handler(CommandHandler("portfolio", self._cmd_portfolio))
        app.add_handler(CommandHandler("balance", self._cmd_balance))
        app.add_handler(CommandHandler("buy", self._cmd_buy))
        app.add_handler(CommandHandler("sell", self._cmd_sell))
        app.add_handler(CommandHandler("analyze", self._cmd_analyze))
        app.add_handler(CommandHandler("positions", self._cmd_positions))
        
        # Callback query handler for inline buttons
        app.add_handler(CallbackQueryHandler(self._handle_callback))
        
        # Error handler
        app.add_error_handler(self._handle_error)
    
    def _is_admin(self, user_id: int) -> bool:
        """Check if user is an admin."""
        return user_id in self.settings.telegram.admin_user_ids
    
    async def _check_auth(self, update: Update) -> bool:
        """Check if user is authorized for trading commands."""
        user_id = update.effective_user.id
        
        if not self._is_admin(user_id):
            await update.message.reply_text(
                "⛔ You are not authorized to use this command."
            )
            return False
        return True
    
    # ========================================================================
    # Command Handlers
    # ========================================================================
    
    async def _cmd_start(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /start command."""
        user = update.effective_user
        
        welcome_msg = (
            f"👋 Welcome, {user.first_name}!\n\n"
            f"I'm a PumpFun token monitoring bot.\n\n"
            f"📊 *Commands:*\n"
            f"/status - Bot status\n"
            f"/portfolio - View portfolio\n"
            f"/balance - Check balance\n"
            f"/positions - Open positions\n"
            f"/analyze <token> - Analyze a token\n"
        )
        
        if self._is_admin(user.id):
            welcome_msg += (
                f"\n🔐 *Admin Commands:*\n"
                f"/buy <amount> <token> - Buy token\n"
                f"/sell <amount> <token> - Sell token\n"
            )
        
        await update.message.reply_text(
            welcome_msg,
            parse_mode="Markdown"
        )
    
    async def _cmd_help(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /help command."""
        await self._cmd_start(update, context)
    
    async def _cmd_status(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /status command."""
        mode = "📝 Paper" if self.settings.trading.paper_trading else "💰 Live"
        
        status_msg = (
            f"🤖 *Bot Status*\n\n"
            f"Trading Mode: {mode}\n"
            f"API Status: ✅ Connected\n"
        )
        
        if self.trading:
            try:
                balance = await self.trading.get_balance()
                status_msg += f"Balance: {format_sol(balance)}\n"
            except Exception:
                status_msg += "Balance: ❌ Error\n"
        
        await update.message.reply_text(status_msg, parse_mode="Markdown")
    
    async def _cmd_balance(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /balance command."""
        if not self.trading:
            await update.message.reply_text("Trading service not available")
            return
        
        try:
            balance = await self.trading.get_balance()
            mode = "Paper" if self.settings.trading.paper_trading else "Live"
            
            await update.message.reply_text(
                f"💰 *Balance ({mode})*\n\n"
                f"{format_sol(balance)}",
                parse_mode="Markdown"
            )
        except Exception as e:
            await update.message.reply_text(f"❌ Error: {str(e)}")
    
    async def _cmd_portfolio(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /portfolio command."""
        if not self.trading:
            await update.message.reply_text("Trading service not available")
            return
        
        try:
            portfolio = await self.trading.get_portfolio()
            mode = "Paper" if portfolio.is_paper else "Live"
            
            pnl_emoji = "🟢" if portfolio.total_unrealized_pnl_sol >= 0 else "🔴"
            
            msg = (
                f"📊 *Portfolio ({mode})*\n\n"
                f"Total Value: {format_sol(portfolio.total_value_sol)}\n"
                f"Cost Basis: {format_sol(portfolio.total_cost_sol)}\n"
                f"{pnl_emoji} Unrealized P&L: {format_sol(portfolio.total_unrealized_pnl_sol)}\n"
                f"Positions: {portfolio.position_count}\n"
            )
            
            if portfolio.positions:
                msg += "\n*Open Positions:*\n"
                for pos in portfolio.positions[:5]:  # Limit to 5
                    pnl_emoji = "🟢" if pos.unrealized_pnl_percent >= 0 else "🔴"
                    msg += (
                        f"• `{truncate_address(pos.token_mint)}`: "
                        f"{pnl_emoji} {format_percent(pos.unrealized_pnl_percent)}\n"
                    )
            
            await update.message.reply_text(msg, parse_mode="Markdown")
            
        except Exception as e:
            await update.message.reply_text(f"❌ Error: {str(e)}")
    
    async def _cmd_positions(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /positions command."""
        await self._cmd_portfolio(update, context)
    
    async def _cmd_analyze(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /analyze <token> command."""
        if not context.args:
            await update.message.reply_text(
                "Usage: /analyze <token_address>\n\n"
                "Example: /analyze 7GCihgDB8fe6KNjn2MYtkzZcRjQy3t9GHdC8uHYmW2hr"
            )
            return
        
        token_address = context.args[0]
        
        await update.message.reply_text("🔍 Analyzing token...")
        
        try:
            # Get token info
            token_info = None
            if self.pumpfun:
                token_info = await self.pumpfun.get_token_details(token_address)
            
            if not token_info:
                await update.message.reply_text(
                    f"❌ Token not found: `{truncate_address(token_address)}`",
                    parse_mode="Markdown"
                )
                return
            
            # Run security analysis
            analysis = None
            if self.security:
                analysis = await self.security.analyze_token(token_info)
            
            # Build response
            msg = self._format_token_analysis(token_info, analysis)
            
            # Add action buttons if authorized
            keyboard = None
            if self._is_admin(update.effective_user.id) and self.settings.telegram.enable_trading_commands:
                keyboard = InlineKeyboardMarkup([
                    [
                        InlineKeyboardButton("🟢 Buy 0.1 SOL", callback_data=f"buy:0.1:{token_address}"),
                        InlineKeyboardButton("🟢 Buy 0.5 SOL", callback_data=f"buy:0.5:{token_address}"),
                    ],
                    [
                        InlineKeyboardButton("📊 Refresh", callback_data=f"analyze:{token_address}"),
                    ]
                ])
            
            await update.message.reply_text(
                msg,
                parse_mode="Markdown",
                reply_markup=keyboard,
                disable_web_page_preview=True
            )
            
            # Store context
            self._user_context[update.effective_user.id] = {
                "token": token_info,
                "analysis": analysis
            }
            
        except Exception as e:
            logger.error("Analysis failed", error=str(e))
            await update.message.reply_text(f"❌ Analysis failed: {str(e)}")
    
    async def _cmd_buy(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /buy <amount> <token> command."""
        if not await self._check_auth(update):
            return
        
        if not self.settings.telegram.enable_trading_commands:
            await update.message.reply_text("Trading commands are disabled")
            return
        
        if len(context.args) < 2:
            await update.message.reply_text(
                "Usage: /buy <amount_sol> <token_address>\n\n"
                "Example: /buy 0.1 7GCihgDB8fe6KNjn2MYtkzZcRjQy3t9GHdC8uHYmW2hr"
            )
            return
        
        try:
            amount = float(context.args[0])
            token_address = context.args[1]
        except ValueError:
            await update.message.reply_text("Invalid amount")
            return
        
        # Confirm
        keyboard = InlineKeyboardMarkup([
            [
                InlineKeyboardButton("✅ Confirm", callback_data=f"confirm_buy:{amount}:{token_address}"),
                InlineKeyboardButton("❌ Cancel", callback_data="cancel"),
            ]
        ])
        
        await update.message.reply_text(
            f"🟢 *Confirm Buy*\n\n"
            f"Token: `{truncate_address(token_address)}`\n"
            f"Amount: {format_sol(amount)}\n",
            parse_mode="Markdown",
            reply_markup=keyboard
        )
    
    async def _cmd_sell(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /sell <amount> <token> command."""
        if not await self._check_auth(update):
            return
        
        if not self.settings.telegram.enable_trading_commands:
            await update.message.reply_text("Trading commands are disabled")
            return
        
        if len(context.args) < 2:
            await update.message.reply_text(
                "Usage: /sell <amount_sol> <token_address>\n\n"
                "Example: /sell 0.1 7GCihgDB8fe6KNjn2MYtkzZcRjQy3t9GHdC8uHYmW2hr"
            )
            return
        
        try:
            amount = float(context.args[0])
            token_address = context.args[1]
        except ValueError:
            await update.message.reply_text("Invalid amount")
            return
        
        keyboard = InlineKeyboardMarkup([
            [
                InlineKeyboardButton("✅ Confirm", callback_data=f"confirm_sell:{amount}:{token_address}"),
                InlineKeyboardButton("❌ Cancel", callback_data="cancel"),
            ]
        ])
        
        await update.message.reply_text(
            f"🔴 *Confirm Sell*\n\n"
            f"Token: `{truncate_address(token_address)}`\n"
            f"Amount: {format_sol(amount)}\n",
            parse_mode="Markdown",
            reply_markup=keyboard
        )
    
    # ========================================================================
    # Callback Handlers
    # ========================================================================
    
    async def _handle_callback(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle inline button callbacks."""
        query = update.callback_query
        await query.answer()
        
        data = query.data
        user_id = update.effective_user.id
        
        if data == "cancel":
            await query.edit_message_text("❌ Cancelled")
            return
        
        if data.startswith("analyze:"):
            token_address = data.split(":")[1]
            # Re-run analysis
            context.args = [token_address]
            await self._cmd_analyze(update, context)
            return
        
        if data.startswith("buy:"):
            parts = data.split(":")
            amount = float(parts[1])
            token_address = parts[2]
            await self._execute_buy(query, amount, token_address)
            return
        
        if data.startswith("confirm_buy:"):
            parts = data.split(":")
            amount = float(parts[1])
            token_address = parts[2]
            await self._execute_buy(query, amount, token_address)
            return
        
        if data.startswith("confirm_sell:"):
            parts = data.split(":")
            amount = float(parts[1])
            token_address = parts[2]
            await self._execute_sell(query, amount, token_address)
            return
    
    async def _execute_buy(self, query, amount: float, token_address: str):
        """Execute a buy order."""
        from ..models.dto import TradeRequest, TradeDirection
        
        if not self.trading:
            await query.edit_message_text("❌ Trading service not available")
            return
        
        await query.edit_message_text("⏳ Executing buy order...")
        
        try:
            request = TradeRequest(
                token_mint=token_address,
                direction=TradeDirection.BUY,
                amount_sol=amount
            )
            
            result = await self.trading.execute_trade(request)
            
            if result.success:
                msg = (
                    f"✅ *Buy Executed*\n\n"
                    f"Token: `{truncate_address(token_address)}`\n"
                    f"Amount: {format_sol(result.executed_amount_sol or amount)}\n"
                    f"Tokens: {result.executed_amount_tokens:.2f}\n"
                    f"Tx: `{result.tx_signature[:16]}...`"
                )
            else:
                msg = f"❌ *Buy Failed*\n\n{result.error_message}"
            
            await query.edit_message_text(msg, parse_mode="Markdown")
            
        except Exception as e:
            await query.edit_message_text(f"❌ Error: {str(e)}")
    
    async def _execute_sell(self, query, amount: float, token_address: str):
        """Execute a sell order."""
        from ..models.dto import TradeRequest, TradeDirection
        
        if not self.trading:
            await query.edit_message_text("❌ Trading service not available")
            return
        
        await query.edit_message_text("⏳ Executing sell order...")
        
        try:
            request = TradeRequest(
                token_mint=token_address,
                direction=TradeDirection.SELL,
                amount_sol=amount
            )
            
            result = await self.trading.execute_trade(request)
            
            if result.success:
                msg = (
                    f"✅ *Sell Executed*\n\n"
                    f"Token: `{truncate_address(token_address)}`\n"
                    f"SOL Received: {format_sol(result.executed_amount_sol or amount)}\n"
                    f"Tx: `{result.tx_signature[:16]}...`"
                )
            else:
                msg = f"❌ *Sell Failed*\n\n{result.error_message}"
            
            await query.edit_message_text(msg, parse_mode="Markdown")
            
        except Exception as e:
            await query.edit_message_text(f"❌ Error: {str(e)}")
    
    async def _handle_error(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle errors."""
        logger.error("Telegram error", error=context.error)
    
    # ========================================================================
    # Alert Sending
    # ========================================================================
    
    async def send_alert(self, alert: Alert):
        """Send an alert to the configured channel."""
        if not self._bot or not self.settings.telegram.channel_id:
            return
        
        try:
            msg = self._format_alert(alert)
            await self._bot.send_message(
                chat_id=self.settings.telegram.channel_id,
                text=msg,
                parse_mode="Markdown",
                disable_web_page_preview=True
            )
            logger.debug("Alert sent", type=alert.alert_type.value)
        except Exception as e:
            logger.error("Failed to send alert", error=str(e))
    
    async def send_new_token_alert(
        self,
        token: TokenInfo,
        analysis: Optional[SecurityAnalysis] = None
    ):
        """Send alert for new token discovery."""
        alert = Alert(
            alert_type=AlertType.NEW_TOKEN,
            title=f"New Token: {token.symbol}",
            message=self._format_token_analysis(token, analysis),
            token_address=token.mint_address,
            token_symbol=token.symbol,
            priority=2 if analysis and analysis.passed else 1
        )
        await self.send_alert(alert)
    
    # ========================================================================
    # Formatting
    # ========================================================================
    
    def _format_token_analysis(
        self,
        token: TokenInfo,
        analysis: Optional[SecurityAnalysis] = None
    ) -> str:
        """Format token analysis for display."""
        verdict_emoji = {
            "safe": "🟢",
            "warning": "🟡", 
            "danger": "🔴",
            "unknown": "⚪"
        }
        
        msg = (
            f"🪙 *{token.name}* ({token.symbol})\n\n"
            f"📍 Address: `{truncate_address(token.mint_address)}`\n"
            f"👤 Creator: `{truncate_address(token.creator_address)}`\n"
            f"💧 Liquidity: {format_sol(token.liquidity_sol)}\n"
            f"👥 Holders: {token.holder_count}\n"
        )
        
        if token.is_graduated:
            msg += f"🎓 Graduated to Raydium\n"
        
        if analysis:
            emoji = verdict_emoji.get(analysis.verdict.value, "⚪")
            msg += (
                f"\n*Security Analysis:*\n"
                f"{emoji} Verdict: {analysis.verdict.value.upper()}\n"
                f"📊 Score: {analysis.overall_score:.0f}/100\n"
            )
            
            if analysis.fail_reasons:
                msg += "\n❌ *Issues:*\n"
                for reason in analysis.fail_reasons[:3]:
                    msg += f"• {reason}\n"
            
            if analysis.warnings and not analysis.fail_reasons:
                msg += "\n⚠️ *Warnings:*\n"
                for warning in analysis.warnings[:3]:
                    msg += f"• {warning}\n"
            
            if analysis.pass_reasons:
                msg += "\n✅ *Positive:*\n"
                for reason in analysis.pass_reasons[:2]:
                    msg += f"• {reason}\n"
        
        # Add links
        if token.metadata:
            links = []
            if token.metadata.website:
                links.append(f"[Website]({token.metadata.website})")
            if token.metadata.twitter:
                links.append(f"[Twitter](https://twitter.com/{token.metadata.twitter})")
            if token.metadata.telegram:
                links.append(f"[Telegram]({token.metadata.telegram})")
            
            if links:
                msg += f"\n🔗 {' | '.join(links)}"
        
        return msg
    
    def _format_alert(self, alert: Alert) -> str:
        """Format alert for display."""
        priority_emoji = ["", "ℹ️", "📢", "⚠️", "🚨", "🔥"][alert.priority]
        
        return (
            f"{priority_emoji} *{alert.title}*\n\n"
            f"{alert.message}"
        )
