"""
PumpFun API client for fetching token data.
"""

import asyncio
from datetime import datetime
from typing import Optional, List, Dict, Any

import aiohttp

from ..config.settings import get_settings
from ..models.dto import (
    TokenInfo, TokenMetadata, TokenDiscoveryEvent,
    PumpFunCoinResponse, PumpFunMigrationResponse
)
from ..utils.helpers import RateLimiter, async_retry, lamports_to_sol
from ..utils.logging import get_logger


logger = get_logger("pumpfun_api")


class PumpFunAPIError(Exception):
    """Custom exception for PumpFun API errors."""
    def __init__(self, message: str, status_code: Optional[int] = None):
        super().__init__(message)
        self.status_code = status_code


class PumpFunAPI:
    """
    Client for interacting with PumpFun's API.
    
    Handles:
    - Fetching new/migrated tokens
    - Getting token details
    - Getting bonding curve data
    """
    
    # Known API endpoints (these may change)
    ENDPOINTS = {
        "coins": "/coins",
        "coin_detail": "/coins/{mint}",
        "trades": "/trades/{mint}",
        "king_of_hill": "/coins/king-of-the-hill",
        "currently_live": "/coins/currently-live",
        "latest": "/coins/latest",
        "graduated": "/coins/graduated",
    }
    
    def __init__(self):
        self.settings = get_settings()
        self.base_url = self.settings.api.pumpfun_api_url.rstrip("/")
        self.timeout = aiohttp.ClientTimeout(
            total=self.settings.api.api_timeout_seconds
        )
        
        # Rate limiting: 30 requests per minute
        self.rate_limiter = RateLimiter(rate=30, per=60)
        
        self._session: Optional[aiohttp.ClientSession] = None
    
    async def _get_session(self) -> aiohttp.ClientSession:
        """Get or create aiohttp session."""
        if self._session is None or self._session.closed:
            headers = {
                "Accept": "application/json",
                "User-Agent": "PumpFunBot/1.0"
            }
            if self.settings.api.pumpfun_api_key:
                headers["Authorization"] = f"Bearer {self.settings.api.pumpfun_api_key.get_secret_value()}"
            
            self._session = aiohttp.ClientSession(
                timeout=self.timeout,
                headers=headers
            )
        return self._session
    
    async def close(self):
        """Close the session."""
        if self._session and not self._session.closed:
            await self._session.close()
    
    @async_retry(max_attempts=3)
    async def _request(
        self,
        method: str,
        endpoint: str,
        params: Optional[Dict] = None,
        **kwargs
    ) -> Dict[str, Any]:
        """Make an API request with rate limiting and retries."""
        await self.rate_limiter.acquire()
        
        session = await self._get_session()
        url = f"{self.base_url}{endpoint}"
        
        logger.debug("API request", method=method, url=url, params=params)
        
        async with session.request(method, url, params=params, **kwargs) as response:
            if response.status == 429:
                # Rate limited - wait and retry
                retry_after = int(response.headers.get("Retry-After", 60))
                logger.warning("Rate limited", retry_after=retry_after)
                await asyncio.sleep(retry_after)
                raise PumpFunAPIError("Rate limited", status_code=429)
            
            if response.status >= 400:
                text = await response.text()
                logger.error(
                    "API error",
                    status=response.status,
                    body=text[:200]
                )
                raise PumpFunAPIError(
                    f"API error: {response.status} - {text[:200]}",
                    status_code=response.status
                )
            
            return await response.json()
    
    # ========================================================================
    # Token Discovery
    # ========================================================================
    
    async def get_latest_tokens(
        self,
        limit: int = 50,
        offset: int = 0,
        include_nsfw: bool = False
    ) -> List[TokenInfo]:
        """
        Get latest tokens from PumpFun.
        
        Args:
            limit: Number of tokens to fetch
            offset: Pagination offset
            include_nsfw: Include NSFW tokens
        
        Returns:
            List of TokenInfo objects
        """
        params = {
            "limit": min(limit, 100),
            "offset": offset,
            "includeNsfw": str(include_nsfw).lower()
        }
        
        try:
            data = await self._request("GET", self.ENDPOINTS["latest"], params=params)
            tokens = []
            
            for item in data if isinstance(data, list) else data.get("data", []):
                token = self._parse_coin_response(item)
                if token:
                    tokens.append(token)
            
            logger.info("Fetched latest tokens", count=len(tokens))
            return tokens
            
        except Exception as e:
            logger.error("Failed to fetch latest tokens", error=str(e))
            return []
    
    async def get_graduated_tokens(
        self,
        limit: int = 50,
        offset: int = 0
    ) -> List[TokenInfo]:
        """
        Get tokens that have graduated to Raydium.
        
        Args:
            limit: Number of tokens to fetch
            offset: Pagination offset
        
        Returns:
            List of TokenInfo objects
        """
        params = {
            "limit": min(limit, 100),
            "offset": offset
        }
        
        try:
            data = await self._request("GET", self.ENDPOINTS["graduated"], params=params)
            tokens = []
            
            for item in data if isinstance(data, list) else data.get("data", []):
                token = self._parse_coin_response(item)
                if token:
                    token.is_graduated = True
                    tokens.append(token)
            
            logger.info("Fetched graduated tokens", count=len(tokens))
            return tokens
            
        except Exception as e:
            logger.error("Failed to fetch graduated tokens", error=str(e))
            return []
    
    async def get_currently_live(self) -> List[TokenInfo]:
        """Get tokens currently on the king of hill page."""
        try:
            data = await self._request("GET", self.ENDPOINTS["currently_live"])
            tokens = []
            
            for item in data if isinstance(data, list) else data.get("data", []):
                token = self._parse_coin_response(item)
                if token:
                    tokens.append(token)
            
            return tokens
            
        except Exception as e:
            logger.error("Failed to fetch live tokens", error=str(e))
            return []
    
    # ========================================================================
    # Token Details
    # ========================================================================
    
    async def get_token_details(self, mint_address: str) -> Optional[TokenInfo]:
        """
        Get detailed information about a specific token.
        
        Args:
            mint_address: Token mint address
        
        Returns:
            TokenInfo or None if not found
        """
        endpoint = self.ENDPOINTS["coin_detail"].format(mint=mint_address)
        
        try:
            data = await self._request("GET", endpoint)
            return self._parse_coin_response(data)
            
        except PumpFunAPIError as e:
            if e.status_code == 404:
                logger.debug("Token not found", mint=mint_address)
                return None
            raise
    
    async def get_token_trades(
        self,
        mint_address: str,
        limit: int = 100,
        offset: int = 0
    ) -> List[Dict[str, Any]]:
        """
        Get recent trades for a token.
        
        Args:
            mint_address: Token mint address
            limit: Number of trades to fetch
            offset: Pagination offset
        
        Returns:
            List of trade dictionaries
        """
        endpoint = self.ENDPOINTS["trades"].format(mint=mint_address)
        params = {"limit": limit, "offset": offset}
        
        try:
            data = await self._request("GET", endpoint, params=params)
            return data if isinstance(data, list) else data.get("data", [])
        except Exception as e:
            logger.error("Failed to fetch trades", mint=mint_address, error=str(e))
            return []
    
    # ========================================================================
    # Parsing
    # ========================================================================
    
    def _parse_coin_response(self, data: Dict[str, Any]) -> Optional[TokenInfo]:
        """Parse PumpFun API response into TokenInfo."""
        try:
            # Handle different response formats
            mint = data.get("mint") or data.get("address") or data.get("token_address")
            if not mint:
                return None
            
            # Calculate price from reserves if available
            price_sol = 0.0
            liquidity_sol = 0.0
            
            virtual_sol = data.get("virtual_sol_reserves") or data.get("virtualSolReserves")
            virtual_token = data.get("virtual_token_reserves") or data.get("virtualTokenReserves")
            real_sol = data.get("real_sol_reserves") or data.get("realSolReserves")
            
            if virtual_sol and virtual_token:
                # Price = SOL reserves / Token reserves
                virtual_sol_float = lamports_to_sol(int(virtual_sol))
                virtual_token_float = int(virtual_token) / 1e6  # Assuming 6 decimals
                if virtual_token_float > 0:
                    price_sol = virtual_sol_float / virtual_token_float
            
            if real_sol:
                liquidity_sol = lamports_to_sol(int(real_sol))
            
            # Parse metadata
            metadata = TokenMetadata(
                name=data.get("name", "Unknown"),
                symbol=data.get("symbol", "???"),
                description=data.get("description"),
                image_url=data.get("image_uri") or data.get("image"),
                website=data.get("website"),
                twitter=data.get("twitter"),
                telegram=data.get("telegram")
            )
            
            # Parse migration time
            migration_time = None
            created_ts = data.get("created_timestamp") or data.get("createdTimestamp")
            if created_ts:
                migration_time = datetime.fromtimestamp(created_ts / 1000)
            
            return TokenInfo(
                mint_address=mint,
                name=metadata.name,
                symbol=metadata.symbol,
                decimals=data.get("decimals", 6),
                creator_address=data.get("creator") or data.get("dev") or "",
                bonding_curve_address=data.get("bonding_curve") or data.get("bondingCurve"),
                liquidity_sol=liquidity_sol,
                market_cap_sol=data.get("market_cap") or data.get("usd_market_cap", 0) / 200,  # Rough SOL conversion
                holder_count=data.get("holder_count", 0),
                price_sol=price_sol,
                is_graduated=data.get("complete", False) or data.get("raydium_pool") is not None,
                migration_time=migration_time,
                raydium_pool_address=data.get("raydium_pool"),
                metadata=metadata
            )
            
        except Exception as e:
            logger.error("Failed to parse coin response", error=str(e), data=str(data)[:200])
            return None
    
    # ========================================================================
    # Utility Methods
    # ========================================================================
    
    async def is_healthy(self) -> bool:
        """Check if API is accessible."""
        try:
            await self._request("GET", self.ENDPOINTS["king_of_hill"])
            return True
        except Exception:
            return False


class PumpFunWebSocket:
    """
    WebSocket client for real-time PumpFun events.
    
    Note: PumpFun's WebSocket API may require authentication
    or have specific connection requirements.
    """
    
    def __init__(self, on_token_callback=None, on_trade_callback=None):
        self.settings = get_settings()
        self.ws_url = "wss://frontend-api.pump.fun/socket.io/?EIO=4&transport=websocket"
        self.on_token = on_token_callback
        self.on_trade = on_trade_callback
        self._ws: Optional[aiohttp.ClientWebSocketResponse] = None
        self._running = False
    
    async def connect(self):
        """Connect to WebSocket."""
        logger.info("Connecting to PumpFun WebSocket")
        
        session = aiohttp.ClientSession()
        try:
            self._ws = await session.ws_connect(self.ws_url)
            self._running = True
            logger.info("WebSocket connected")
            
            # Start listening
            await self._listen()
            
        except Exception as e:
            logger.error("WebSocket connection failed", error=str(e))
            raise
        finally:
            await session.close()
    
    async def _listen(self):
        """Listen for WebSocket messages."""
        while self._running and self._ws:
            try:
                msg = await self._ws.receive(timeout=30)
                
                if msg.type == aiohttp.WSMsgType.TEXT:
                    await self._handle_message(msg.data)
                elif msg.type == aiohttp.WSMsgType.CLOSED:
                    logger.warning("WebSocket closed")
                    break
                elif msg.type == aiohttp.WSMsgType.ERROR:
                    logger.error("WebSocket error")
                    break
                    
            except asyncio.TimeoutError:
                # Send ping to keep alive
                await self._ws.ping()
    
    async def _handle_message(self, data: str):
        """Handle incoming WebSocket message."""
        try:
            # Socket.io protocol - messages prefixed with type
            if data.startswith("42"):
                # Event message
                import json
                payload = json.loads(data[2:])
                event_type = payload[0] if payload else None
                event_data = payload[1] if len(payload) > 1 else None
                
                if event_type == "newCoin" and self.on_token:
                    await self.on_token(event_data)
                elif event_type == "tradeCreated" and self.on_trade:
                    await self.on_trade(event_data)
                    
        except Exception as e:
            logger.error("Failed to handle WebSocket message", error=str(e))
    
    async def disconnect(self):
        """Disconnect from WebSocket."""
        self._running = False
        if self._ws:
            await self._ws.close()
            logger.info("WebSocket disconnected")
    
    async def subscribe_to_token(self, mint_address: str):
        """Subscribe to updates for a specific token."""
        if self._ws:
            # Socket.io subscribe message
            await self._ws.send_str(f'42["subscribeTokenTrade","{mint_address}"]')
