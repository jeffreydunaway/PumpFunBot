"""
Database models using SQLAlchemy ORM with async support.
"""

from datetime import datetime
from decimal import Decimal
from enum import Enum
from typing import Optional, List

from sqlalchemy import (
    String, Integer, Float, Boolean, DateTime, Text, 
    ForeignKey, Index, UniqueConstraint, Numeric
)
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, relationship
from sqlalchemy.sql import func


class Base(DeclarativeBase):
    """Base class for all models."""
    pass


class TradeDirection(str, Enum):
    BUY = "buy"
    SELL = "sell"


class TradeStatus(str, Enum):
    PENDING = "pending"
    SUBMITTED = "submitted"
    CONFIRMED = "confirmed"
    FAILED = "failed"
    CANCELLED = "cancelled"


class SecurityVerdict(str, Enum):
    SAFE = "safe"
    WARNING = "warning"
    DANGER = "danger"
    UNKNOWN = "unknown"


class Token(Base):
    """Token/coin information."""
    
    __tablename__ = "tokens"
    
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    mint_address: Mapped[str] = mapped_column(String(64), unique=True, nullable=False, index=True)
    name: Mapped[str] = mapped_column(String(128), nullable=False)
    symbol: Mapped[str] = mapped_column(String(32), nullable=False)
    decimals: Mapped[int] = mapped_column(Integer, default=9)
    
    # Creator info
    creator_address: Mapped[str] = mapped_column(String(64), nullable=False, index=True)
    bonding_curve_address: Mapped[Optional[str]] = mapped_column(String(64), nullable=True)
    
    # Token metrics at discovery
    initial_liquidity_sol: Mapped[float] = mapped_column(Float, default=0.0)
    initial_market_cap_sol: Mapped[float] = mapped_column(Float, default=0.0)
    holder_count: Mapped[int] = mapped_column(Integer, default=0)
    
    # Migration info
    migration_time: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)
    raydium_pool_address: Mapped[Optional[str]] = mapped_column(String(64), nullable=True)
    
    # Metadata
    image_url: Mapped[Optional[str]] = mapped_column(String(512), nullable=True)
    description: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    website: Mapped[Optional[str]] = mapped_column(String(256), nullable=True)
    twitter: Mapped[Optional[str]] = mapped_column(String(128), nullable=True)
    telegram: Mapped[Optional[str]] = mapped_column(String(128), nullable=True)
    
    # Tracking
    is_graduated: Mapped[bool] = mapped_column(Boolean, default=False)
    is_blacklisted: Mapped[bool] = mapped_column(Boolean, default=False)
    blacklist_reason: Mapped[Optional[str]] = mapped_column(String(256), nullable=True)
    
    # Timestamps
    discovered_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now())
    updated_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now(), onupdate=func.now())
    
    # Relationships
    security_checks: Mapped[List["SecurityCheck"]] = relationship(back_populates="token", cascade="all, delete-orphan")
    price_snapshots: Mapped[List["PriceSnapshot"]] = relationship(back_populates="token", cascade="all, delete-orphan")
    trades: Mapped[List["Trade"]] = relationship(back_populates="token", cascade="all, delete-orphan")
    
    __table_args__ = (
        Index("idx_token_creator", "creator_address"),
        Index("idx_token_discovered", "discovered_at"),
    )


class SecurityCheck(Base):
    """Security analysis results for a token."""
    
    __tablename__ = "security_checks"
    
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    token_id: Mapped[int] = mapped_column(ForeignKey("tokens.id", ondelete="CASCADE"), nullable=False)
    
    # RugCheck results
    rugcheck_score: Mapped[Optional[float]] = mapped_column(Float, nullable=True)
    rugcheck_verdict: Mapped[str] = mapped_column(String(32), default=SecurityVerdict.UNKNOWN.value)
    rugcheck_risks: Mapped[Optional[str]] = mapped_column(Text, nullable=True)  # JSON array
    
    # GoPlus results
    goplus_is_honeypot: Mapped[Optional[bool]] = mapped_column(Boolean, nullable=True)
    goplus_buy_tax: Mapped[Optional[float]] = mapped_column(Float, nullable=True)
    goplus_sell_tax: Mapped[Optional[float]] = mapped_column(Float, nullable=True)
    goplus_is_mintable: Mapped[Optional[bool]] = mapped_column(Boolean, nullable=True)
    goplus_can_freeze: Mapped[Optional[bool]] = mapped_column(Boolean, nullable=True)
    
    # Holder analysis
    top_holder_percent: Mapped[Optional[float]] = mapped_column(Float, nullable=True)
    top_10_holder_percent: Mapped[Optional[float]] = mapped_column(Float, nullable=True)
    is_bundled_launch: Mapped[bool] = mapped_column(Boolean, default=False)
    
    # LP analysis
    lp_locked: Mapped[Optional[bool]] = mapped_column(Boolean, nullable=True)
    lp_lock_duration_days: Mapped[Optional[int]] = mapped_column(Integer, nullable=True)
    lp_burned: Mapped[Optional[bool]] = mapped_column(Boolean, nullable=True)
    
    # Overall verdict
    passed_checks: Mapped[bool] = mapped_column(Boolean, default=False)
    failure_reasons: Mapped[Optional[str]] = mapped_column(Text, nullable=True)  # JSON array
    
    checked_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now())
    
    # Relationships
    token: Mapped["Token"] = relationship(back_populates="security_checks")
    
    __table_args__ = (
        Index("idx_security_token", "token_id"),
        Index("idx_security_checked", "checked_at"),
    )


class PriceSnapshot(Base):
    """Price and volume snapshots for tracking."""
    
    __tablename__ = "price_snapshots"
    
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    token_id: Mapped[int] = mapped_column(ForeignKey("tokens.id", ondelete="CASCADE"), nullable=False)
    
    price_sol: Mapped[float] = mapped_column(Float, nullable=False)
    price_usd: Mapped[Optional[float]] = mapped_column(Float, nullable=True)
    market_cap_sol: Mapped[Optional[float]] = mapped_column(Float, nullable=True)
    volume_24h_sol: Mapped[Optional[float]] = mapped_column(Float, nullable=True)
    liquidity_sol: Mapped[Optional[float]] = mapped_column(Float, nullable=True)
    holder_count: Mapped[Optional[int]] = mapped_column(Integer, nullable=True)
    
    timestamp: Mapped[datetime] = mapped_column(DateTime, server_default=func.now())
    
    # Relationships
    token: Mapped["Token"] = relationship(back_populates="price_snapshots")
    
    __table_args__ = (
        Index("idx_price_token_time", "token_id", "timestamp"),
    )


class Trade(Base):
    """Trading activity records."""
    
    __tablename__ = "trades"
    
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    token_id: Mapped[int] = mapped_column(ForeignKey("tokens.id", ondelete="CASCADE"), nullable=False)
    
    # Trade details
    direction: Mapped[str] = mapped_column(String(8), nullable=False)  # buy/sell
    status: Mapped[str] = mapped_column(String(16), default=TradeStatus.PENDING.value)
    
    # Amounts
    amount_sol: Mapped[float] = mapped_column(Float, nullable=False)
    amount_tokens: Mapped[Optional[float]] = mapped_column(Float, nullable=True)
    price_per_token: Mapped[Optional[float]] = mapped_column(Float, nullable=True)
    
    # Execution
    slippage_bps: Mapped[int] = mapped_column(Integer, default=150)
    priority_fee_lamports: Mapped[int] = mapped_column(Integer, default=0)
    
    # Transaction
    tx_signature: Mapped[Optional[str]] = mapped_column(String(128), nullable=True, unique=True)
    block_slot: Mapped[Optional[int]] = mapped_column(Integer, nullable=True)
    
    # Results
    executed_amount_sol: Mapped[Optional[float]] = mapped_column(Float, nullable=True)
    executed_amount_tokens: Mapped[Optional[float]] = mapped_column(Float, nullable=True)
    gas_fee_sol: Mapped[Optional[float]] = mapped_column(Float, nullable=True)
    
    # Paper trading flag
    is_paper_trade: Mapped[bool] = mapped_column(Boolean, default=True)
    
    # Error handling
    error_message: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    retry_count: Mapped[int] = mapped_column(Integer, default=0)
    
    # Timestamps
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now())
    executed_at: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)
    
    # Relationships
    token: Mapped["Token"] = relationship(back_populates="trades")
    
    __table_args__ = (
        Index("idx_trade_token", "token_id"),
        Index("idx_trade_status", "status"),
        Index("idx_trade_created", "created_at"),
    )


class Position(Base):
    """Current portfolio positions."""
    
    __tablename__ = "positions"
    
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    token_mint: Mapped[str] = mapped_column(String(64), unique=True, nullable=False)
    
    # Position details
    amount_tokens: Mapped[float] = mapped_column(Float, nullable=False)
    average_entry_price: Mapped[float] = mapped_column(Float, nullable=False)
    total_cost_sol: Mapped[float] = mapped_column(Float, nullable=False)
    
    # Risk management
    stop_loss_price: Mapped[Optional[float]] = mapped_column(Float, nullable=True)
    take_profit_price: Mapped[Optional[float]] = mapped_column(Float, nullable=True)
    trailing_stop_percent: Mapped[Optional[float]] = mapped_column(Float, nullable=True)
    highest_price_seen: Mapped[Optional[float]] = mapped_column(Float, nullable=True)
    
    # P&L tracking
    realized_pnl_sol: Mapped[float] = mapped_column(Float, default=0.0)
    unrealized_pnl_sol: Mapped[Optional[float]] = mapped_column(Float, nullable=True)
    
    # Paper trading
    is_paper_position: Mapped[bool] = mapped_column(Boolean, default=True)
    
    # Timestamps
    opened_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now())
    updated_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now(), onupdate=func.now())
    closed_at: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)


class CreatorStats(Base):
    """Statistics about token creators."""
    
    __tablename__ = "creator_stats"
    
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    creator_address: Mapped[str] = mapped_column(String(64), unique=True, nullable=False, index=True)
    
    # Token creation stats
    total_tokens_created: Mapped[int] = mapped_column(Integer, default=0)
    successful_migrations: Mapped[int] = mapped_column(Integer, default=0)
    rugged_tokens: Mapped[int] = mapped_column(Integer, default=0)
    
    # Reputation
    reputation_score: Mapped[float] = mapped_column(Float, default=50.0)
    is_blacklisted: Mapped[bool] = mapped_column(Boolean, default=False)
    blacklist_reason: Mapped[Optional[str]] = mapped_column(String(256), nullable=True)
    
    # Timestamps
    first_seen: Mapped[datetime] = mapped_column(DateTime, server_default=func.now())
    last_seen: Mapped[datetime] = mapped_column(DateTime, server_default=func.now(), onupdate=func.now())


class BotState(Base):
    """Persistent bot state for recovery."""
    
    __tablename__ = "bot_state"
    
    key: Mapped[str] = mapped_column(String(64), primary_key=True)
    value: Mapped[str] = mapped_column(Text, nullable=False)
    updated_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now(), onupdate=func.now())
