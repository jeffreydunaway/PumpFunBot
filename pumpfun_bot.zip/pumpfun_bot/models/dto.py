"""
Pydantic models for data transfer and validation.
"""

from datetime import datetime
from decimal import Decimal
from enum import Enum
from typing import Optional, List, Dict, Any

from pydantic import BaseModel, Field, field_validator


class TradeDirection(str, Enum):
    BUY = "buy"
    SELL = "sell"


class SecurityVerdict(str, Enum):
    SAFE = "safe"
    WARNING = "warning"
    DANGER = "danger"
    UNKNOWN = "unknown"


# ============================================================================
# Token DTOs
# ============================================================================

class TokenMetadata(BaseModel):
    """Token metadata from PumpFun."""
    name: str
    symbol: str
    description: Optional[str] = None
    image_url: Optional[str] = None
    website: Optional[str] = None
    twitter: Optional[str] = None
    telegram: Optional[str] = None


class TokenInfo(BaseModel):
    """Core token information."""
    mint_address: str
    name: str
    symbol: str
    decimals: int = 9
    creator_address: str
    bonding_curve_address: Optional[str] = None
    
    # Metrics
    liquidity_sol: float = 0.0
    market_cap_sol: float = 0.0
    holder_count: int = 0
    price_sol: float = 0.0
    
    # Status
    is_graduated: bool = False
    migration_time: Optional[datetime] = None
    raydium_pool_address: Optional[str] = None
    
    # Metadata
    metadata: Optional[TokenMetadata] = None
    
    @field_validator("mint_address", "creator_address", mode="before")
    @classmethod
    def validate_address(cls, v):
        if v and len(v) < 32:
            raise ValueError("Invalid Solana address")
        return v


class TokenDiscoveryEvent(BaseModel):
    """Event when a new token is discovered."""
    token: TokenInfo
    discovery_source: str = "api_poll"
    discovered_at: datetime = Field(default_factory=datetime.utcnow)


# ============================================================================
# Security DTOs
# ============================================================================

class RugCheckResult(BaseModel):
    """Results from RugCheck API."""
    score: float = Field(ge=0, le=100)
    verdict: SecurityVerdict = SecurityVerdict.UNKNOWN
    risks: List[str] = Field(default_factory=list)
    
    # Detailed checks
    top_holder_percent: Optional[float] = None
    is_mintable: Optional[bool] = None
    has_freeze_authority: Optional[bool] = None
    lp_locked: Optional[bool] = None
    lp_burned: Optional[bool] = None


class GoPlusResult(BaseModel):
    """Results from GoPlus Security API."""
    is_honeypot: bool = False
    buy_tax: float = 0.0
    sell_tax: float = 0.0
    is_mintable: bool = False
    can_freeze: bool = False
    is_proxy: bool = False
    has_blacklist: bool = False
    
    # Additional flags
    is_open_source: Optional[bool] = None
    is_in_dex: Optional[bool] = None
    holder_count: Optional[int] = None


class SecurityAnalysis(BaseModel):
    """Combined security analysis."""
    token_address: str
    
    rugcheck: Optional[RugCheckResult] = None
    goplus: Optional[GoPlusResult] = None
    
    # Aggregated results
    overall_score: float = 50.0
    verdict: SecurityVerdict = SecurityVerdict.UNKNOWN
    passed: bool = False
    
    # Reasons for pass/fail
    pass_reasons: List[str] = Field(default_factory=list)
    fail_reasons: List[str] = Field(default_factory=list)
    warnings: List[str] = Field(default_factory=list)
    
    analyzed_at: datetime = Field(default_factory=datetime.utcnow)


# ============================================================================
# Trading DTOs
# ============================================================================

class TradeRequest(BaseModel):
    """Request to execute a trade."""
    token_mint: str
    direction: TradeDirection
    amount_sol: float = Field(gt=0)
    slippage_bps: int = Field(default=150, ge=0, le=5000)
    priority_fee_lamports: int = Field(default=100000, ge=0)
    
    # Risk management
    stop_loss_percent: Optional[float] = Field(default=None, ge=0, le=100)
    take_profit_percent: Optional[float] = Field(default=None, ge=0)


class TradeResult(BaseModel):
    """Result of a trade execution."""
    success: bool
    trade_id: Optional[int] = None
    tx_signature: Optional[str] = None
    
    # Execution details
    direction: TradeDirection
    requested_amount_sol: float
    executed_amount_sol: Optional[float] = None
    executed_amount_tokens: Optional[float] = None
    price_per_token: Optional[float] = None
    gas_fee_sol: Optional[float] = None
    
    # Error info
    error_code: Optional[str] = None
    error_message: Optional[str] = None
    
    executed_at: Optional[datetime] = None


class PositionInfo(BaseModel):
    """Current position information."""
    token_mint: str
    token_symbol: str
    
    amount_tokens: float
    average_entry_price: float
    current_price: float
    total_cost_sol: float
    current_value_sol: float
    
    # P&L
    unrealized_pnl_sol: float
    unrealized_pnl_percent: float
    realized_pnl_sol: float = 0.0
    
    # Risk levels
    stop_loss_price: Optional[float] = None
    take_profit_price: Optional[float] = None
    
    is_paper: bool = True
    opened_at: datetime


class PortfolioSummary(BaseModel):
    """Portfolio overview."""
    total_value_sol: float
    total_cost_sol: float
    total_unrealized_pnl_sol: float
    total_realized_pnl_sol: float
    
    position_count: int
    positions: List[PositionInfo] = Field(default_factory=list)
    
    is_paper: bool = True
    updated_at: datetime = Field(default_factory=datetime.utcnow)


# ============================================================================
# Alert DTOs
# ============================================================================

class AlertType(str, Enum):
    NEW_TOKEN = "new_token"
    SECURITY_WARNING = "security_warning"
    TRADE_EXECUTED = "trade_executed"
    STOP_LOSS_HIT = "stop_loss_hit"
    TAKE_PROFIT_HIT = "take_profit_hit"
    PRICE_ALERT = "price_alert"
    ERROR = "error"


class Alert(BaseModel):
    """Alert notification."""
    alert_type: AlertType
    title: str
    message: str
    
    token_address: Optional[str] = None
    token_symbol: Optional[str] = None
    
    data: Dict[str, Any] = Field(default_factory=dict)
    priority: int = Field(default=1, ge=1, le=5)  # 1=low, 5=critical
    
    created_at: datetime = Field(default_factory=datetime.utcnow)


# ============================================================================
# API Response DTOs
# ============================================================================

class PumpFunMigrationResponse(BaseModel):
    """Response from PumpFun migrations endpoint."""
    mint: str
    name: str
    symbol: str
    description: Optional[str] = None
    image_uri: Optional[str] = None
    
    bonding_curve: str
    associated_bonding_curve: Optional[str] = None
    creator: str
    
    virtual_sol_reserves: Optional[int] = None
    virtual_token_reserves: Optional[int] = None
    real_sol_reserves: Optional[int] = None
    real_token_reserves: Optional[int] = None
    
    complete: bool = False
    raydium_pool: Optional[str] = None
    
    created_timestamp: Optional[int] = None
    
    website: Optional[str] = None
    twitter: Optional[str] = None
    telegram: Optional[str] = None


class PumpFunCoinResponse(BaseModel):
    """Response from PumpFun coin details endpoint."""
    mint: str
    name: str
    symbol: str
    description: Optional[str] = None
    image_uri: Optional[str] = None
    metadata_uri: Optional[str] = None
    
    bonding_curve: str
    creator: str
    
    usd_market_cap: Optional[float] = None
    market_cap: Optional[float] = None  # in SOL
    
    reply_count: Optional[int] = None
    last_reply: Optional[int] = None
    
    complete: bool = False
    raydium_pool: Optional[str] = None
    king_of_the_hill_timestamp: Optional[int] = None
    
    created_timestamp: Optional[int] = None
    
    website: Optional[str] = None
    twitter: Optional[str] = None
    telegram: Optional[str] = None
