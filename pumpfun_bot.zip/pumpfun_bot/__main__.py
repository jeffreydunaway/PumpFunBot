#!/usr/bin/env python3
"""
PumpFun Bot - Main Entry Point

A production-ready Solana token monitoring and trading bot for PumpFun.

Usage:
    python -m pumpfun_bot           # Run the bot
    python -m pumpfun_bot --help    # Show help

Environment Variables:
    See .env.example for all configuration options.
"""

import argparse
import asyncio
import sys
from pathlib import Path


def parse_args():
    """Parse command line arguments."""
    parser = argparse.ArgumentParser(
        description="PumpFun Token Monitoring Bot",
        formatter_class=argparse.RawDescriptionHelpFormatter
    )
    
    parser.add_argument(
        "--config",
        type=str,
        default=".env",
        help="Path to environment file (default: .env)"
    )
    
    parser.add_argument(
        "--debug",
        action="store_true",
        help="Enable debug mode"
    )
    
    parser.add_argument(
        "--paper",
        action="store_true",
        default=True,
        help="Run in paper trading mode (default: True)"
    )
    
    parser.add_argument(
        "--live",
        action="store_true",
        help="Run in live trading mode (CAUTION: Real money)"
    )
    
    parser.add_argument(
        "--init-db",
        action="store_true",
        help="Initialize database and exit"
    )
    
    return parser.parse_args()


async def init_database():
    """Initialize database schema."""
    from pumpfun_bot.services.database import DatabaseService
    
    db = DatabaseService()
    await db.init_db()
    await db.close()
    print("Database initialized successfully!")


async def run():
    """Main entry point."""
    args = parse_args()
    
    # Load environment file if exists
    env_path = Path(args.config)
    if env_path.exists():
        from dotenv import load_dotenv
        load_dotenv(env_path)
    
    # Handle init-db command
    if args.init_db:
        await init_database()
        return
    
    # Override settings based on args
    import os
    
    if args.debug:
        os.environ["PUMPFUN_DEBUG"] = "true"
        os.environ["PUMPFUN_LOG_LEVEL"] = "DEBUG"
    
    if args.live:
        os.environ["PUMPFUN_TRADING_PAPER_TRADING"] = "false"
        print("⚠️  WARNING: Running in LIVE trading mode!")
        print("    Real transactions will be executed.")
        print("    Press Ctrl+C within 5 seconds to cancel...")
        try:
            await asyncio.sleep(5)
        except asyncio.CancelledError:
            print("Cancelled.")
            return
    
    # Run the bot
    from pumpfun_bot.core.bot import PumpFunBot
    
    bot = PumpFunBot()
    await bot.start()


def main():
    """Synchronous entry point."""
    try:
        asyncio.run(run())
    except KeyboardInterrupt:
        print("\nShutdown requested...")
    except Exception as e:
        print(f"Fatal error: {e}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
