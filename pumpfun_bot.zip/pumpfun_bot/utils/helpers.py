"""
Async utilities and helper functions.
"""

import asyncio
import functools
import time
from datetime import datetime, timedelta
from typing import TypeVar, Callable, Awaitable, Optional, Any, Dict
from collections import defaultdict

import aiohttp
from tenacity import (
    retry,
    stop_after_attempt,
    wait_exponential,
    retry_if_exception_type
)

T = TypeVar("T")


# ============================================================================
# Retry Decorators
# ============================================================================

def async_retry(
    max_attempts: int = 3,
    min_wait: float = 1.0,
    max_wait: float = 10.0,
    exceptions: tuple = (aiohttp.ClientError, asyncio.TimeoutError)
):
    """
    Decorator for retrying async functions with exponential backoff.
    
    Args:
        max_attempts: Maximum number of retry attempts
        min_wait: Minimum wait time between retries (seconds)
        max_wait: Maximum wait time between retries (seconds)
        exceptions: Tuple of exception types to retry on
    """
    return retry(
        stop=stop_after_attempt(max_attempts),
        wait=wait_exponential(multiplier=1, min=min_wait, max=max_wait),
        retry=retry_if_exception_type(exceptions),
        reraise=True
    )


# ============================================================================
# Rate Limiting
# ============================================================================

class RateLimiter:
    """
    Token bucket rate limiter for API calls.
    Thread-safe and supports async operations.
    """
    
    def __init__(
        self,
        rate: float,
        per: float = 1.0,
        burst: Optional[int] = None
    ):
        """
        Initialize rate limiter.
        
        Args:
            rate: Number of requests allowed
            per: Time period in seconds
            burst: Maximum burst size (defaults to rate)
        """
        self.rate = rate
        self.per = per
        self.burst = burst or int(rate)
        
        self.tokens = float(self.burst)
        self.last_update = time.monotonic()
        self._lock = asyncio.Lock()
    
    async def acquire(self, tokens: int = 1) -> float:
        """
        Acquire tokens, waiting if necessary.
        
        Returns:
            Time waited in seconds
        """
        async with self._lock:
            waited = 0.0
            
            while True:
                now = time.monotonic()
                elapsed = now - self.last_update
                self.last_update = now
                
                # Add tokens based on elapsed time
                self.tokens = min(
                    self.burst,
                    self.tokens + elapsed * (self.rate / self.per)
                )
                
                if self.tokens >= tokens:
                    self.tokens -= tokens
                    return waited
                
                # Calculate wait time
                needed = tokens - self.tokens
                wait_time = needed * (self.per / self.rate)
                
                await asyncio.sleep(wait_time)
                waited += wait_time
    
    async def __aenter__(self):
        await self.acquire()
        return self
    
    async def __aexit__(self, *args):
        pass


class MultiRateLimiter:
    """Rate limiter that manages multiple endpoints."""
    
    def __init__(self):
        self._limiters: Dict[str, RateLimiter] = {}
        self._lock = asyncio.Lock()
    
    async def get_limiter(
        self,
        key: str,
        rate: float = 10,
        per: float = 1.0
    ) -> RateLimiter:
        """Get or create a rate limiter for a key."""
        async with self._lock:
            if key not in self._limiters:
                self._limiters[key] = RateLimiter(rate, per)
            return self._limiters[key]
    
    async def acquire(self, key: str, rate: float = 10, per: float = 1.0):
        """Acquire a token for the given key."""
        limiter = await self.get_limiter(key, rate, per)
        return await limiter.acquire()


# ============================================================================
# Circuit Breaker
# ============================================================================

class CircuitBreaker:
    """
    Circuit breaker pattern for failing fast on repeated errors.
    """
    
    class CircuitOpen(Exception):
        """Raised when circuit is open."""
        pass
    
    def __init__(
        self,
        failure_threshold: int = 5,
        recovery_timeout: float = 30.0,
        half_open_max: int = 3
    ):
        """
        Initialize circuit breaker.
        
        Args:
            failure_threshold: Number of failures before opening circuit
            recovery_timeout: Seconds to wait before attempting recovery
            half_open_max: Max requests to allow in half-open state
        """
        self.failure_threshold = failure_threshold
        self.recovery_timeout = recovery_timeout
        self.half_open_max = half_open_max
        
        self._failures = 0
        self._last_failure_time: Optional[float] = None
        self._state = "closed"
        self._half_open_count = 0
        self._lock = asyncio.Lock()
    
    @property
    def is_open(self) -> bool:
        return self._state == "open"
    
    @property
    def is_closed(self) -> bool:
        return self._state == "closed"
    
    async def _check_state(self):
        """Check and potentially update circuit state."""
        if self._state == "open" and self._last_failure_time:
            if time.monotonic() - self._last_failure_time >= self.recovery_timeout:
                self._state = "half-open"
                self._half_open_count = 0
    
    async def call(
        self,
        func: Callable[..., Awaitable[T]],
        *args,
        **kwargs
    ) -> T:
        """
        Execute function with circuit breaker protection.
        
        Raises:
            CircuitOpen: If circuit is open
        """
        async with self._lock:
            await self._check_state()
            
            if self._state == "open":
                raise self.CircuitOpen(
                    f"Circuit is open. Retry after {self.recovery_timeout}s"
                )
            
            if self._state == "half-open":
                if self._half_open_count >= self.half_open_max:
                    raise self.CircuitOpen("Circuit half-open limit reached")
                self._half_open_count += 1
        
        try:
            result = await func(*args, **kwargs)
            
            async with self._lock:
                # Success - reset or close circuit
                self._failures = 0
                self._state = "closed"
            
            return result
            
        except Exception as e:
            async with self._lock:
                self._failures += 1
                self._last_failure_time = time.monotonic()
                
                if self._failures >= self.failure_threshold:
                    self._state = "open"
            
            raise


# ============================================================================
# Async Utilities
# ============================================================================

async def gather_with_concurrency(
    n: int,
    *tasks: Awaitable[T]
) -> list[T]:
    """
    Run tasks with limited concurrency.
    
    Args:
        n: Maximum concurrent tasks
        tasks: Awaitables to execute
    
    Returns:
        List of results in order
    """
    semaphore = asyncio.Semaphore(n)
    
    async def limited_task(task):
        async with semaphore:
            return await task
    
    return await asyncio.gather(*[limited_task(t) for t in tasks])


async def timeout_wrapper(
    coro: Awaitable[T],
    timeout: float,
    default: Optional[T] = None
) -> Optional[T]:
    """
    Wrap a coroutine with a timeout, returning default on timeout.
    """
    try:
        return await asyncio.wait_for(coro, timeout=timeout)
    except asyncio.TimeoutError:
        return default


class AsyncCache:
    """Simple async-safe LRU cache with TTL."""
    
    def __init__(self, maxsize: int = 100, ttl: float = 60.0):
        self.maxsize = maxsize
        self.ttl = ttl
        self._cache: Dict[str, tuple[Any, float]] = {}
        self._lock = asyncio.Lock()
    
    async def get(self, key: str) -> Optional[Any]:
        """Get value if exists and not expired."""
        async with self._lock:
            if key in self._cache:
                value, timestamp = self._cache[key]
                if time.monotonic() - timestamp < self.ttl:
                    return value
                del self._cache[key]
        return None
    
    async def set(self, key: str, value: Any):
        """Set a value with current timestamp."""
        async with self._lock:
            # Evict oldest if at capacity
            if len(self._cache) >= self.maxsize:
                oldest_key = min(
                    self._cache.keys(),
                    key=lambda k: self._cache[k][1]
                )
                del self._cache[oldest_key]
            
            self._cache[key] = (value, time.monotonic())
    
    async def delete(self, key: str):
        """Delete a key if it exists."""
        async with self._lock:
            self._cache.pop(key, None)
    
    async def clear(self):
        """Clear all cached values."""
        async with self._lock:
            self._cache.clear()


# ============================================================================
# Helpers
# ============================================================================

def lamports_to_sol(lamports: int) -> float:
    """Convert lamports to SOL."""
    return lamports / 1_000_000_000


def sol_to_lamports(sol: float) -> int:
    """Convert SOL to lamports."""
    return int(sol * 1_000_000_000)


def calculate_price_impact(
    input_amount: float,
    input_reserve: float,
    output_reserve: float,
    fee_bps: int = 30  # 0.3% default
) -> tuple[float, float]:
    """
    Calculate AMM swap output and price impact.
    
    Returns:
        Tuple of (output_amount, price_impact_percent)
    """
    fee_multiplier = 1 - (fee_bps / 10000)
    input_with_fee = input_amount * fee_multiplier
    
    # Constant product formula: x * y = k
    output_amount = (output_reserve * input_with_fee) / (input_reserve + input_with_fee)
    
    # Calculate price impact
    spot_price = output_reserve / input_reserve
    execution_price = output_amount / input_amount
    price_impact = ((spot_price - execution_price) / spot_price) * 100
    
    return output_amount, max(0, price_impact)


def format_sol(amount: float, decimals: int = 4) -> str:
    """Format SOL amount for display."""
    return f"{amount:,.{decimals}f} SOL"


def format_percent(value: float, decimals: int = 2) -> str:
    """Format percentage for display."""
    sign = "+" if value > 0 else ""
    return f"{sign}{value:.{decimals}f}%"


def truncate_address(address: str, chars: int = 4) -> str:
    """Truncate address for display."""
    if len(address) <= chars * 2 + 3:
        return address
    return f"{address[:chars]}...{address[-chars:]}"
