"""
Tests for security analysis service.
"""

import pytest
from unittest.mock import AsyncMock, patch, MagicMock

from pumpfun_bot.services.security import SecurityService
from pumpfun_bot.models.dto import (
    TokenInfo, SecurityAnalysis, SecurityVerdict,
    RugCheckResult, GoPlusResult
)


class TestSecurityService:
    """Tests for SecurityService."""
    
    @pytest.fixture
    def security_service(self):
        """Create security service instance."""
        with patch("pumpfun_bot.services.security.get_settings") as mock_settings:
            settings = MagicMock()
            settings.api.rugcheck_api_url = "https://api.rugcheck.xyz/v1"
            settings.api.rugcheck_api_key = None
            settings.api.goplus_api_url = "https://api.gopluslabs.io/api/v1"
            settings.filters.min_liquidity_sol = 5.0
            settings.filters.max_top_holder_percent = 20.0
            settings.filters.max_buy_tax_percent = 10.0
            settings.filters.max_sell_tax_percent = 10.0
            settings.filters.min_holders = 25
            settings.filters.min_rugcheck_score = 50.0
            settings.blacklist.token_addresses = set()
            settings.blacklist.creator_addresses = set()
            settings.blacklist.remote_blacklist_url = None
            mock_settings.return_value = settings
            
            return SecurityService()
    
    def test_init(self, security_service):
        """Test service initialization."""
        assert security_service is not None
        assert security_service.rugcheck_url == "https://api.rugcheck.xyz/v1"
    
    def test_is_token_blacklisted(self, security_service):
        """Test token blacklist check."""
        security_service._token_blacklist.add("BlacklistedToken123")
        
        assert security_service.is_token_blacklisted("BlacklistedToken123") is True
        assert security_service.is_token_blacklisted("SafeToken456") is False
    
    def test_is_creator_blacklisted(self, security_service):
        """Test creator blacklist check."""
        security_service._creator_blacklist.add("ScammerWallet123")
        
        assert security_service.is_creator_blacklisted("ScammerWallet123") is True
        assert security_service.is_creator_blacklisted("LegitCreator456") is False
    
    def test_add_to_blacklist(self, security_service):
        """Test adding to blacklists."""
        security_service.add_to_blacklist("NewScamToken")
        assert "NewScamToken" in security_service._token_blacklist
        
        security_service.add_to_blacklist("NewScamCreator", is_creator=True)
        assert "NewScamCreator" in security_service._creator_blacklist
    
    @pytest.mark.asyncio
    async def test_analyze_token_blacklisted(self, security_service, sample_token):
        """Test that blacklisted tokens fail immediately."""
        security_service._token_blacklist.add(sample_token.mint_address)
        
        analysis = await security_service.analyze_token(sample_token)
        
        assert analysis.passed is False
        assert analysis.verdict == SecurityVerdict.DANGER
        assert "blacklisted" in analysis.fail_reasons[0].lower()
    
    @pytest.mark.asyncio
    async def test_analyze_token_creator_blacklisted(self, security_service, sample_token):
        """Test that tokens from blacklisted creators fail."""
        security_service._creator_blacklist.add(sample_token.creator_address)
        
        analysis = await security_service.analyze_token(sample_token)
        
        assert analysis.passed is False
        assert analysis.verdict == SecurityVerdict.DANGER
        assert "creator" in analysis.fail_reasons[0].lower()
    
    def test_parse_rugcheck_response_safe(self, security_service):
        """Test parsing a safe RugCheck response."""
        response = {
            "score": 85,
            "verdict": "Good",
            "risks": [],
            "topHolders": [{"address": "...", "percentage": 5.0}],
            "mintable": False,
            "freezeAuthority": None,
            "lpLocked": True,
            "lpBurned": False
        }
        
        result = security_service._parse_rugcheck_response(response)
        
        assert result.score == 85
        assert result.verdict == SecurityVerdict.SAFE
        assert result.top_holder_percent == 5.0
        assert result.is_mintable is False
        assert result.lp_locked is True
    
    def test_parse_rugcheck_response_danger(self, security_service):
        """Test parsing a dangerous RugCheck response."""
        response = {
            "score": 20,
            "verdict": "Danger",
            "risks": [
                {"name": "High ownership", "description": "Top holder owns 90%"}
            ],
            "topHolders": [{"address": "...", "percentage": 90.0}],
            "mintable": True,
            "freezeAuthority": "SomeAuthority",
        }
        
        result = security_service._parse_rugcheck_response(response)
        
        assert result.score == 20
        assert result.verdict == SecurityVerdict.DANGER
        assert result.top_holder_percent == 90.0
        assert result.is_mintable is True
        assert result.has_freeze_authority is True
        assert len(result.risks) > 0
    
    def test_parse_goplus_response(self, security_service):
        """Test parsing GoPlus response."""
        response = {
            "is_honeypot": "0",
            "buy_tax": "0.05",
            "sell_tax": "0.05",
            "is_mintable": "0",
            "can_freeze": "0",
            "is_proxy": "0",
            "is_blacklisted": "0",
            "holder_count": "150"
        }
        
        result = security_service._parse_goplus_response(response)
        
        assert result.is_honeypot is False
        assert result.buy_tax == 5.0  # Converted to percent
        assert result.sell_tax == 5.0
        assert result.is_mintable is False
        assert result.holder_count == 150
    
    def test_evaluate_security_passes(self, security_service, sample_token):
        """Test security evaluation with passing results."""
        analysis = SecurityAnalysis(token_address=sample_token.mint_address)
        analysis.rugcheck = RugCheckResult(
            score=80,
            verdict=SecurityVerdict.SAFE,
            top_holder_percent=10.0,
            lp_locked=True
        )
        analysis.goplus = GoPlusResult(
            is_honeypot=False,
            buy_tax=2.0,
            sell_tax=2.0
        )
        
        security_service._evaluate_security(analysis, sample_token, [])
        
        assert analysis.passed is True
        assert analysis.verdict == SecurityVerdict.SAFE
        assert analysis.overall_score >= 70
    
    def test_evaluate_security_fails_honeypot(self, security_service, sample_token):
        """Test that honeypot detection fails the token."""
        analysis = SecurityAnalysis(token_address=sample_token.mint_address)
        analysis.rugcheck = RugCheckResult(score=80, verdict=SecurityVerdict.SAFE)
        analysis.goplus = GoPlusResult(is_honeypot=True)
        
        security_service._evaluate_security(analysis, sample_token, [])
        
        assert analysis.passed is False
        assert analysis.overall_score == 0
        assert any("honeypot" in r.lower() for r in analysis.fail_reasons)
    
    def test_evaluate_security_fails_high_tax(self, security_service, sample_token):
        """Test that high tax fails the token."""
        analysis = SecurityAnalysis(token_address=sample_token.mint_address)
        analysis.rugcheck = RugCheckResult(score=80, verdict=SecurityVerdict.SAFE)
        analysis.goplus = GoPlusResult(
            is_honeypot=False,
            buy_tax=25.0,  # High tax
            sell_tax=25.0
        )
        
        security_service._evaluate_security(analysis, sample_token, [])
        
        assert analysis.passed is False
        assert any("tax" in r.lower() for r in analysis.fail_reasons)
    
    def test_evaluate_security_warns_mintable(self, security_service, sample_token):
        """Test that mintable tokens get warnings."""
        analysis = SecurityAnalysis(token_address=sample_token.mint_address)
        analysis.rugcheck = RugCheckResult(
            score=70,
            verdict=SecurityVerdict.WARNING,
            is_mintable=True
        )
        
        security_service._evaluate_security(analysis, sample_token, [])
        
        assert any("mintable" in w.lower() for w in analysis.warnings)


class TestSecurityFilters:
    """Tests for security filter logic."""
    
    @pytest.fixture
    def security_service(self):
        """Create security service with specific filter settings."""
        with patch("pumpfun_bot.services.security.get_settings") as mock_settings:
            settings = MagicMock()
            settings.api.rugcheck_api_url = "https://api.rugcheck.xyz/v1"
            settings.api.rugcheck_api_key = None
            settings.api.goplus_api_url = "https://api.gopluslabs.io/api/v1"
            settings.filters.min_liquidity_sol = 5.0
            settings.filters.max_top_holder_percent = 20.0
            settings.filters.max_buy_tax_percent = 10.0
            settings.filters.max_sell_tax_percent = 10.0
            settings.filters.min_holders = 25
            settings.filters.min_rugcheck_score = 50.0
            settings.blacklist.token_addresses = set()
            settings.blacklist.creator_addresses = set()
            settings.blacklist.remote_blacklist_url = None
            mock_settings.return_value = settings
            
            return SecurityService()
    
    def test_low_liquidity_fails(self, security_service, sample_token_risky):
        """Test that low liquidity tokens fail."""
        analysis = SecurityAnalysis(token_address=sample_token_risky.mint_address)
        analysis.rugcheck = RugCheckResult(score=80, verdict=SecurityVerdict.SAFE)
        
        security_service._evaluate_security(analysis, sample_token_risky, [])
        
        assert any("liquidity" in r.lower() for r in analysis.fail_reasons)
    
    def test_high_holder_concentration_fails(self, security_service, sample_token):
        """Test that high holder concentration fails."""
        analysis = SecurityAnalysis(token_address=sample_token.mint_address)
        analysis.rugcheck = RugCheckResult(
            score=80,
            verdict=SecurityVerdict.SAFE,
            top_holder_percent=50.0  # Way above 20% limit
        )
        
        security_service._evaluate_security(analysis, sample_token, [])
        
        assert any("holder" in r.lower() for r in analysis.fail_reasons)
    
    def test_creator_issues_reduce_score(self, security_service, sample_token):
        """Test that creator issues reduce score."""
        analysis = SecurityAnalysis(token_address=sample_token.mint_address)
        analysis.rugcheck = RugCheckResult(score=80, verdict=SecurityVerdict.SAFE)
        
        creator_issues = ["Creator has launched 5 tokens (limit: 3)"]
        security_service._evaluate_security(analysis, sample_token, creator_issues)
        
        assert analysis.overall_score < 80  # Reduced from rugcheck score
        assert any("creator" in w.lower() for w in analysis.warnings)
