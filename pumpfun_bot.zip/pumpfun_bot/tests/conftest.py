"""
Test configuration and fixtures.
"""

import asyncio
import os
from datetime import datetime
from typing import AsyncGenerator

import pytest
import pytest_asyncio
from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession, async_sessionmaker

from pumpfun_bot.models.database import Base
from pumpfun_bot.models.dto import TokenInfo, TokenMetadata


# Set test environment
os.environ["PUMPFUN_ENVIRONMENT"] = "test"
os.environ["PUMPFUN_DB_URL"] = "sqlite+aiosqlite:///:memory:"
os.environ["PUMPFUN_TRADING_PAPER_TRADING"] = "true"
os.environ["PUMPFUN_LOG_LEVEL"] = "DEBUG"


@pytest.fixture(scope="session")
def event_loop():
    """Create event loop for async tests."""
    loop = asyncio.get_event_loop_policy().new_event_loop()
    yield loop
    loop.close()


@pytest_asyncio.fixture
async def db_engine():
    """Create test database engine."""
    engine = create_async_engine(
        "sqlite+aiosqlite:///:memory:",
        echo=False
    )
    
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    
    yield engine
    
    await engine.dispose()


@pytest_asyncio.fixture
async def db_session(db_engine) -> AsyncGenerator[AsyncSession, None]:
    """Create test database session."""
    async_session = async_sessionmaker(
        db_engine,
        class_=AsyncSession,
        expire_on_commit=False
    )
    
    async with async_session() as session:
        yield session


@pytest.fixture
def sample_token() -> TokenInfo:
    """Create a sample token for testing."""
    return TokenInfo(
        mint_address="7GCihgDB8fe6KNjn2MYtkzZcRjQy3t9GHdC8uHYmW2hr",
        name="Test Token",
        symbol="TEST",
        decimals=6,
        creator_address="9WzDXwBbmkg8ZTbNMqUxvQRAyrZzDsGYdLVL9zYtAWWM",
        bonding_curve_address="BondingCurveAddress123",
        liquidity_sol=10.5,
        market_cap_sol=50.0,
        holder_count=100,
        price_sol=0.0001,
        is_graduated=False,
        migration_time=datetime.utcnow(),
        metadata=TokenMetadata(
            name="Test Token",
            symbol="TEST",
            description="A test token for unit testing",
            image_url="https://example.com/image.png",
            website="https://test.com",
            twitter="testtoken",
            telegram="https://t.me/testtoken"
        )
    )


@pytest.fixture
def sample_token_risky() -> TokenInfo:
    """Create a risky token for testing security filters."""
    return TokenInfo(
        mint_address="RiskyToken111111111111111111111111111111111",
        name="Risky Token",
        symbol="RISK",
        decimals=6,
        creator_address="ScammerWallet1111111111111111111111111111111",
        liquidity_sol=0.5,  # Low liquidity
        market_cap_sol=5.0,
        holder_count=5,  # Low holders
        price_sol=0.00001,
        is_graduated=False,
    )
