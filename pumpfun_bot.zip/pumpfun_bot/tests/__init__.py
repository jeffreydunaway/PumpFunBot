# Tests for PumpFun Bot
