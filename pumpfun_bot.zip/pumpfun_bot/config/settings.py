"""
Configuration management with Pydantic validation.
Supports environment variables and .env files for secure credential handling.
"""

import os
from pathlib import Path
from typing import Optional, Set
from functools import lru_cache

from pydantic import Field, field_validator, SecretStr
from pydantic_settings import BaseSettings, SettingsConfigDict


class APISettings(BaseSettings):
    """API configuration for external services."""
    
    model_config = SettingsConfigDict(
        env_prefix="PUMPFUN_API_",
        env_file=".env",
        extra="ignore"
    )
    
    # Solana RPC endpoints
    solana_rpc_url: str = Field(
        default="https://api.mainnet-beta.solana.com",
        description="Solana RPC endpoint URL"
    )
    solana_ws_url: str = Field(
        default="wss://api.mainnet-beta.solana.com",
        description="Solana WebSocket endpoint"
    )
    
    # PumpFun API
    pumpfun_api_url: str = Field(
        default="https://frontend-api.pump.fun",
        description="PumpFun API base URL"
    )
    pumpfun_api_key: Optional[SecretStr] = Field(
        default=None,
        description="PumpFun API key if required"
    )
    
    # External security APIs
    rugcheck_api_url: str = Field(
        default="https://api.rugcheck.xyz/v1",
        description="RugCheck API URL"
    )
    rugcheck_api_key: Optional[SecretStr] = Field(
        default=None,
        description="RugCheck API key"
    )
    
    goplus_api_url: str = Field(
        default="https://api.gopluslabs.io/api/v1",
        description="GoPlus Security API URL"
    )
    
    # Rate limiting
    poll_interval_seconds: int = Field(default=30, ge=5, le=300)
    api_timeout_seconds: int = Field(default=10, ge=1, le=60)
    max_retries: int = Field(default=3, ge=1, le=10)


class FilterSettings(BaseSettings):
    """Token filtering criteria."""
    
    model_config = SettingsConfigDict(
        env_prefix="PUMPFUN_FILTER_",
        env_file=".env",
        extra="ignore"
    )
    
    # Liquidity requirements
    min_liquidity_sol: float = Field(default=5.0, ge=0)
    max_liquidity_sol: float = Field(default=1000.0, ge=0)
    
    # Token metrics
    min_holders: int = Field(default=25, ge=1)
    max_top_holder_percent: float = Field(default=20.0, ge=0, le=100)
    min_token_age_minutes: int = Field(default=10, ge=0)
    max_creator_tokens: int = Field(default=3, ge=1)
    
    # Fee limits
    max_buy_tax_percent: float = Field(default=10.0, ge=0, le=100)
    max_sell_tax_percent: float = Field(default=10.0, ge=0, le=100)
    
    # Security score thresholds
    min_rugcheck_score: float = Field(default=50.0, ge=0, le=100)
    
    @field_validator("max_liquidity_sol")
    @classmethod
    def max_must_exceed_min(cls, v, info):
        if "min_liquidity_sol" in info.data and v < info.data["min_liquidity_sol"]:
            raise ValueError("max_liquidity_sol must be >= min_liquidity_sol")
        return v


class TradingSettings(BaseSettings):
    """Trading parameters and risk management."""
    
    model_config = SettingsConfigDict(
        env_prefix="PUMPFUN_TRADING_",
        env_file=".env",
        extra="ignore"
    )
    
    # Position sizing
    default_buy_amount_sol: float = Field(default=0.1, ge=0.001)
    max_position_sol: float = Field(default=1.0, ge=0.001)
    max_portfolio_percent: float = Field(default=10.0, ge=0, le=100)
    
    # Risk management
    stop_loss_percent: float = Field(default=15.0, ge=0, le=100)
    take_profit_percent: float = Field(default=50.0, ge=0)
    trailing_stop_percent: Optional[float] = Field(default=None, ge=0, le=100)
    
    # Execution
    slippage_bps: int = Field(default=150, ge=0, le=5000)  # basis points
    priority_fee_lamports: int = Field(default=100000, ge=0)
    max_retries: int = Field(default=3, ge=1, le=10)
    
    # Trading mode
    paper_trading: bool = Field(
        default=True,
        description="Enable paper trading mode (no real transactions)"
    )


class TelegramSettings(BaseSettings):
    """Telegram bot configuration."""
    
    model_config = SettingsConfigDict(
        env_prefix="PUMPFUN_TELEGRAM_",
        env_file=".env",
        extra="ignore"
    )
    
    bot_token: Optional[SecretStr] = Field(default=None)
    channel_id: Optional[str] = Field(default=None)
    admin_user_ids: Set[int] = Field(default_factory=set)
    enable_trading_commands: bool = Field(default=False)
    
    @field_validator("admin_user_ids", mode="before")
    @classmethod
    def parse_admin_ids(cls, v):
        if isinstance(v, str):
            return {int(x.strip()) for x in v.split(",") if x.strip()}
        return v or set()


class DatabaseSettings(BaseSettings):
    """Database configuration."""
    
    model_config = SettingsConfigDict(
        env_prefix="PUMPFUN_DB_",
        env_file=".env",
        extra="ignore"
    )
    
    url: str = Field(
        default="sqlite+aiosqlite:///pumpfun_bot.db",
        description="Database URL (supports SQLite, PostgreSQL)"
    )
    echo: bool = Field(default=False, description="Enable SQL query logging")
    pool_size: int = Field(default=5, ge=1, le=20)


class BlacklistSettings(BaseSettings):
    """Blacklist configuration."""
    
    model_config = SettingsConfigDict(
        env_prefix="PUMPFUN_BLACKLIST_",
        env_file=".env",
        extra="ignore"
    )
    
    token_addresses: Set[str] = Field(default_factory=set)
    creator_addresses: Set[str] = Field(default_factory=set)
    remote_blacklist_url: Optional[str] = Field(default=None)
    update_interval_minutes: int = Field(default=60, ge=5)
    
    @field_validator("token_addresses", "creator_addresses", mode="before")
    @classmethod
    def parse_addresses(cls, v):
        if isinstance(v, str):
            return {x.strip() for x in v.split(",") if x.strip()}
        return v or set()


class Settings(BaseSettings):
    """Main settings container."""
    
    model_config = SettingsConfigDict(
        env_file=".env",
        extra="ignore"
    )
    
    # Environment
    environment: str = Field(default="development")
    debug: bool = Field(default=False)
    log_level: str = Field(default="INFO")
    
    # Sub-settings
    api: APISettings = Field(default_factory=APISettings)
    filters: FilterSettings = Field(default_factory=FilterSettings)
    trading: TradingSettings = Field(default_factory=TradingSettings)
    telegram: TelegramSettings = Field(default_factory=TelegramSettings)
    database: DatabaseSettings = Field(default_factory=DatabaseSettings)
    blacklist: BlacklistSettings = Field(default_factory=BlacklistSettings)


@lru_cache()
def get_settings() -> Settings:
    """Get cached settings instance."""
    return Settings()
