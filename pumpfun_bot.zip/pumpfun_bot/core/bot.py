"""
Main bot orchestrator - coordinates all services and runs the main loop.
"""

import asyncio
import signal
from datetime import datetime, timedelta
from typing import Optional, Set, List

from ..config.settings import get_settings, Settings
from ..models.dto import TokenInfo, TokenDiscoveryEvent, Alert, AlertType
from ..services.database import DatabaseService
from ..services.pumpfun_api import PumpFunAPI
from ..services.security import SecurityService
from ..services.trading import TradingService
from ..services.telegram_bot import TelegramService
from ..utils.logging import setup_logging, get_logger


logger = get_logger("core")


class PumpFunBot:
    """
    Main bot orchestrator.
    
    Responsibilities:
    - Initialize and manage all services
    - Run the main token monitoring loop
    - Coordinate between discovery, analysis, and trading
    - Handle graceful shutdown
    """
    
    def __init__(self, settings: Optional[Settings] = None):
        self.settings = settings or get_settings()
        
        # Services (initialized in start())
        self.db: Optional[DatabaseService] = None
        self.pumpfun: Optional[PumpFunAPI] = None
        self.security: Optional[SecurityService] = None
        self.trading: Optional[TradingService] = None
        self.telegram: Optional[TelegramService] = None
        
        # State
        self._running = False
        self._seen_tokens: Set[str] = set()
        self._last_blacklist_refresh = datetime.min
        
        # Shutdown event
        self._shutdown_event = asyncio.Event()
    
    async def start(self):
        """Initialize all services and start the bot."""
        logger.info("Starting PumpFun Bot...")
        
        # Setup logging
        setup_logging(
            level=self.settings.log_level,
            json_format=self.settings.environment == "production"
        )
        
        # Initialize services
        await self._init_services()
        
        # Load previously seen tokens
        await self._load_seen_tokens()
        
        # Register signal handlers
        self._setup_signal_handlers()
        
        self._running = True
        logger.info(
            "Bot started",
            mode="paper" if self.settings.trading.paper_trading else "live",
            environment=self.settings.environment
        )
        
        # Run main loop
        try:
            await self._main_loop()
        except asyncio.CancelledError:
            logger.info("Bot cancelled")
        finally:
            await self.stop()
    
    async def stop(self):
        """Gracefully stop all services."""
        logger.info("Stopping bot...")
        self._running = False
        
        # Stop services in reverse order
        if self.telegram:
            await self.telegram.stop()
        
        if self.trading:
            await self.trading.close()
        
        if self.security:
            await self.security.close()
        
        if self.pumpfun:
            await self.pumpfun.close()
        
        if self.db:
            await self.db.close()
        
        logger.info("Bot stopped")
    
    async def _init_services(self):
        """Initialize all services."""
        # Database first (others depend on it)
        self.db = DatabaseService()
        await self.db.init_db()
        logger.info("Database initialized")
        
        # PumpFun API
        self.pumpfun = PumpFunAPI()
        if await self.pumpfun.is_healthy():
            logger.info("PumpFun API connected")
        else:
            logger.warning("PumpFun API not responding")
        
        # Security service
        self.security = SecurityService(database_service=self.db)
        await self.security.refresh_blacklists()
        logger.info("Security service initialized")
        
        # Trading service
        self.trading = TradingService(
            database_service=self.db,
            pumpfun_api=self.pumpfun
        )
        logger.info(
            "Trading service initialized",
            mode="paper" if self.settings.trading.paper_trading else "live"
        )
        
        # Telegram bot
        self.telegram = TelegramService(
            trading_service=self.trading,
            pumpfun_api=self.pumpfun,
            security_service=self.security,
            database_service=self.db
        )
        await self.telegram.start()
        logger.info("Telegram service initialized")
    
    async def _load_seen_tokens(self):
        """Load recently seen tokens from database."""
        if not self.db:
            return
        
        # Load tokens seen in the last 24 hours
        since = datetime.utcnow() - timedelta(hours=24)
        recent_tokens = await self.db.get_recent_tokens(limit=1000, since=since)
        
        for token in recent_tokens:
            self._seen_tokens.add(token.mint_address)
        
        logger.info("Loaded seen tokens", count=len(self._seen_tokens))
    
    def _setup_signal_handlers(self):
        """Setup graceful shutdown handlers."""
        loop = asyncio.get_event_loop()
        
        for sig in (signal.SIGINT, signal.SIGTERM):
            loop.add_signal_handler(
                sig,
                lambda: asyncio.create_task(self._signal_handler())
            )
    
    async def _signal_handler(self):
        """Handle shutdown signals."""
        logger.info("Shutdown signal received")
        self._shutdown_event.set()
    
    # ========================================================================
    # Main Loop
    # ========================================================================
    
    async def _main_loop(self):
        """Main monitoring loop."""
        poll_interval = self.settings.api.poll_interval_seconds
        
        while self._running:
            try:
                # Check for shutdown
                if self._shutdown_event.is_set():
                    break
                
                # Refresh blacklists periodically
                await self._maybe_refresh_blacklists()
                
                # Fetch and process new tokens
                await self._process_new_tokens()
                
                # Check positions for stop-loss/take-profit
                await self._check_positions()
                
                # Wait before next iteration
                try:
                    await asyncio.wait_for(
                        self._shutdown_event.wait(),
                        timeout=poll_interval
                    )
                    break  # Shutdown requested
                except asyncio.TimeoutError:
                    pass  # Normal timeout, continue loop
                
            except Exception as e:
                logger.error("Main loop error", error=str(e))
                await asyncio.sleep(10)  # Brief pause on error
    
    async def _maybe_refresh_blacklists(self):
        """Refresh blacklists if interval has passed."""
        refresh_interval = timedelta(
            minutes=self.settings.blacklist.update_interval_minutes
        )
        
        if datetime.utcnow() - self._last_blacklist_refresh > refresh_interval:
            if self.security:
                await self.security.refresh_blacklists()
            self._last_blacklist_refresh = datetime.utcnow()
    
    async def _process_new_tokens(self):
        """Fetch and process new tokens."""
        if not self.pumpfun:
            return
        
        # Fetch latest tokens
        tokens = await self.pumpfun.get_latest_tokens(limit=50)
        
        # Also fetch graduated tokens
        graduated = await self.pumpfun.get_graduated_tokens(limit=20)
        tokens.extend(graduated)
        
        new_count = 0
        for token in tokens:
            # Skip if already seen
            if token.mint_address in self._seen_tokens:
                continue
            
            self._seen_tokens.add(token.mint_address)
            new_count += 1
            
            # Process the new token
            await self._process_token(token)
        
        if new_count > 0:
            logger.info("Processed new tokens", count=new_count)
    
    async def _process_token(self, token: TokenInfo):
        """Process a single token through the pipeline."""
        logger.debug(
            "Processing token",
            mint=token.mint_address,
            symbol=token.symbol
        )
        
        # Quick blacklist check
        if self.security:
            if self.security.is_token_blacklisted(token.mint_address):
                logger.debug("Token blacklisted", mint=token.mint_address)
                return
            
            if self.security.is_creator_blacklisted(token.creator_address):
                logger.debug("Creator blacklisted", creator=token.creator_address)
                return
        
        # Apply basic filters
        if not self._passes_basic_filters(token):
            return
        
        # Run security analysis
        analysis = None
        if self.security:
            analysis = await self.security.analyze_token(token)
        
        # Save to database
        if self.db:
            db_token = await self.db.save_token(token)
            
            if analysis:
                await self.db.save_security_check(db_token.id, analysis)
            
            # Update creator stats
            await self.db.update_creator_stats(token.creator_address)
        
        # Send alert if passed checks
        if analysis and analysis.passed:
            logger.info(
                "Token passed security checks",
                mint=token.mint_address,
                symbol=token.symbol,
                score=analysis.overall_score
            )
            
            if self.telegram:
                await self.telegram.send_new_token_alert(token, analysis)
        
        elif analysis:
            logger.debug(
                "Token failed security checks",
                mint=token.mint_address,
                reasons=analysis.fail_reasons[:2]
            )
    
    def _passes_basic_filters(self, token: TokenInfo) -> bool:
        """Apply basic filters before full analysis."""
        filters = self.settings.filters
        
        # Liquidity check
        if token.liquidity_sol < filters.min_liquidity_sol:
            return False
        
        if token.liquidity_sol > filters.max_liquidity_sol:
            return False
        
        # Holder check
        if token.holder_count < filters.min_holders:
            return False
        
        # Age check
        if token.migration_time:
            min_age = timedelta(minutes=filters.min_token_age_minutes)
            if datetime.utcnow() - token.migration_time < min_age:
                return False
        
        return True
    
    async def _check_positions(self):
        """Check open positions for stop-loss/take-profit."""
        if not self.trading or not self.db:
            return
        
        positions = await self.db.get_all_open_positions()
        
        for position in positions:
            try:
                # Get current price
                pos_info = await self.trading.get_position(position.token_mint)
                if not pos_info:
                    continue
                
                # Check stop-loss
                if position.stop_loss_price and pos_info.current_price <= position.stop_loss_price:
                    logger.warning(
                        "Stop-loss triggered",
                        token=position.token_mint,
                        price=pos_info.current_price,
                        stop_loss=position.stop_loss_price
                    )
                    
                    # Execute sell
                    from ..models.dto import TradeRequest, TradeDirection
                    
                    request = TradeRequest(
                        token_mint=position.token_mint,
                        direction=TradeDirection.SELL,
                        amount_sol=pos_info.current_value_sol
                    )
                    
                    result = await self.trading.execute_trade(request)
                    
                    # Send alert
                    if self.telegram:
                        await self.telegram.send_alert(Alert(
                            alert_type=AlertType.STOP_LOSS_HIT,
                            title="Stop Loss Triggered",
                            message=f"Sold {position.token_mint} at {pos_info.current_price}",
                            token_address=position.token_mint,
                            priority=4
                        ))
                
                # Check take-profit
                elif position.take_profit_price and pos_info.current_price >= position.take_profit_price:
                    logger.info(
                        "Take-profit triggered",
                        token=position.token_mint,
                        price=pos_info.current_price,
                        take_profit=position.take_profit_price
                    )
                    
                    from ..models.dto import TradeRequest, TradeDirection
                    
                    request = TradeRequest(
                        token_mint=position.token_mint,
                        direction=TradeDirection.SELL,
                        amount_sol=pos_info.current_value_sol
                    )
                    
                    result = await self.trading.execute_trade(request)
                    
                    if self.telegram:
                        await self.telegram.send_alert(Alert(
                            alert_type=AlertType.TAKE_PROFIT_HIT,
                            title="Take Profit Triggered",
                            message=f"Sold {position.token_mint} at {pos_info.current_price}",
                            token_address=position.token_mint,
                            priority=3
                        ))
                
                # Update trailing stop if enabled
                elif position.trailing_stop_percent:
                    if position.highest_price_seen is None or pos_info.current_price > position.highest_price_seen:
                        # Update highest price
                        async with self.db.session() as session:
                            from sqlalchemy import update
                            from ..models.database import Position
                            
                            new_stop = pos_info.current_price * (1 - position.trailing_stop_percent / 100)
                            
                            await session.execute(
                                update(Position)
                                .where(Position.token_mint == position.token_mint)
                                .values(
                                    highest_price_seen=pos_info.current_price,
                                    stop_loss_price=new_stop
                                )
                            )
                
            except Exception as e:
                logger.error(
                    "Error checking position",
                    token=position.token_mint,
                    error=str(e)
                )


async def run_bot():
    """Entry point for running the bot."""
    bot = PumpFunBot()
    await bot.start()


def main():
    """Synchronous entry point."""
    asyncio.run(run_bot())


if __name__ == "__main__":
    main()
